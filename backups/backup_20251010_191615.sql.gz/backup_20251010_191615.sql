--
-- PostgreSQL database dump
--

\restrict UzprzrWjLsDMn9IAO1lVB5jPlua2AwWo73F5QH3v1sSkNlBmQR6hf6NTvwFxBht

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AddressType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AddressType" AS ENUM (
    'SHIPPING',
    'BILLING',
    'BOTH'
);


ALTER TYPE public."AddressType" OWNER TO postgres;

--
-- Name: AnnotationVisibility; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AnnotationVisibility" AS ENUM (
    'PRIVATE_TO_EMPLOYEE',
    'SHARED_WITH_CLIENT'
);


ALTER TYPE public."AnnotationVisibility" OWNER TO postgres;

--
-- Name: AppointmentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppointmentStatus" AS ENUM (
    'SCHEDULED',
    'CONFIRMED',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'NO_SHOW'
);


ALTER TYPE public."AppointmentStatus" OWNER TO postgres;

--
-- Name: BudgetPeriod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BudgetPeriod" AS ENUM (
    'MONTHLY',
    'QUARTERLY',
    'YEARLY',
    'CUSTOM'
);


ALTER TYPE public."BudgetPeriod" OWNER TO postgres;

--
-- Name: BudgetStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BudgetStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."BudgetStatus" OWNER TO postgres;

--
-- Name: CartStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CartStatus" AS ENUM (
    'ACTIVE',
    'ABANDONED',
    'CONVERTED',
    'EXPIRED'
);


ALTER TYPE public."CartStatus" OWNER TO postgres;

--
-- Name: ClientStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ClientStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED',
    'TRIAL'
);


ALTER TYPE public."ClientStatus" OWNER TO postgres;

--
-- Name: CouponType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CouponType" AS ENUM (
    'PERCENTAGE',
    'FIXED',
    'FREE_SHIPPING'
);


ALTER TYPE public."CouponType" OWNER TO postgres;

--
-- Name: EcommerceOrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EcommerceOrderStatus" AS ENUM (
    'PENDING',
    'PAID',
    'CONFIRMED',
    'PROCESSING',
    'SHIPPED',
    'OUT_FOR_DELIVERY',
    'DELIVERED',
    'CANCELLED',
    'REFUNDED',
    'RETURNED'
);


ALTER TYPE public."EcommerceOrderStatus" OWNER TO postgres;

--
-- Name: Gender; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Gender" AS ENUM (
    'MALE',
    'FEMALE',
    'OTHER'
);


ALTER TYPE public."Gender" OWNER TO postgres;

--
-- Name: GoalPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GoalPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."GoalPriority" OWNER TO postgres;

--
-- Name: GoalStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GoalStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'PAUSED',
    'CANCELLED'
);


ALTER TYPE public."GoalStatus" OWNER TO postgres;

--
-- Name: LeadPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeadPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."LeadPriority" OWNER TO postgres;

--
-- Name: LeadStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeadStatus" AS ENUM (
    'NEW',
    'CONTACTED',
    'QUALIFIED',
    'PROPOSAL_SENT',
    'NEGOTIATING',
    'CLOSED_WON',
    'CLOSED_LOST'
);


ALTER TYPE public."LeadStatus" OWNER TO postgres;

--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'ADJUSTMENT',
    'TRANSFER',
    'LOSS',
    'RETURN'
);


ALTER TYPE public."MovementType" OWNER TO postgres;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationType" AS ENUM (
    'TRANSACTION_CREATED',
    'TRANSACTION_UPDATED',
    'TRANSACTION_DELETED',
    'GOAL_CREATED',
    'GOAL_UPDATED',
    'GOAL_COMPLETED',
    'BUDGET_CREATED',
    'BUDGET_UPDATED',
    'BUDGET_EXCEEDED',
    'MEMBER_ADDED',
    'MEMBER_REMOVED',
    'PERMISSION_CHANGED',
    'WORKSPACE_UPDATED',
    'GENERAL'
);


ALTER TYPE public."NotificationType" OWNER TO postgres;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'PREPARING',
    'READY',
    'OUT_FOR_DELIVERY',
    'DELIVERED',
    'CANCELLED'
);


ALTER TYPE public."OrderStatus" OWNER TO postgres;

--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CREDIT_CARD',
    'DEBIT_CARD',
    'PIX',
    'BANK_SLIP',
    'BANK_TRANSFER',
    'CASH',
    'PAYPAL',
    'OTHER'
);


ALTER TYPE public."PaymentMethod" OWNER TO postgres;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED',
    'REFUNDED',
    'PARTIALLY_REFUNDED'
);


ALTER TYPE public."PaymentStatus" OWNER TO postgres;

--
-- Name: PropertyStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PropertyStatus" AS ENUM (
    'AVAILABLE',
    'RESERVED',
    'SOLD',
    'RENTED',
    'MAINTENANCE',
    'INACTIVE'
);


ALTER TYPE public."PropertyStatus" OWNER TO postgres;

--
-- Name: PropertyType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PropertyType" AS ENUM (
    'HOUSE',
    'APARTMENT',
    'COMMERCIAL',
    'LAND',
    'FARM',
    'WAREHOUSE'
);


ALTER TYPE public."PropertyType" OWNER TO postgres;

--
-- Name: ScheduleCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ScheduleCategory" AS ENUM (
    'WORK',
    'PERSONAL',
    'MEETING',
    'APPOINTMENT',
    'REMINDER',
    'OTHER'
);


ALTER TYPE public."ScheduleCategory" OWNER TO postgres;

--
-- Name: SchedulePriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SchedulePriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."SchedulePriority" OWNER TO postgres;

--
-- Name: ScheduleStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ScheduleStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'POSTPONED'
);


ALTER TYPE public."ScheduleStatus" OWNER TO postgres;

--
-- Name: ShipmentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ShipmentStatus" AS ENUM (
    'PREPARING',
    'SHIPPED',
    'IN_TRANSIT',
    'OUT_FOR_DELIVERY',
    'DELIVERED',
    'FAILED',
    'RETURNED'
);


ALTER TYPE public."ShipmentStatus" OWNER TO postgres;

--
-- Name: TransactionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TransactionStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'CANCELLED'
);


ALTER TYPE public."TransactionStatus" OWNER TO postgres;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TransactionType" AS ENUM (
    'INCOME',
    'EXPENSE'
);


ALTER TYPE public."TransactionType" OWNER TO postgres;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'EMPLOYEE',
    'CLIENT',
    'GUEST'
);


ALTER TYPE public."UserRole" OWNER TO postgres;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED',
    'PENDING_VERIFICATION'
);


ALTER TYPE public."UserStatus" OWNER TO postgres;

--
-- Name: VisitStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."VisitStatus" AS ENUM (
    'SCHEDULED',
    'CONFIRMED',
    'COMPLETED',
    'CANCELLED',
    'NO_SHOW'
);


ALTER TYPE public."VisitStatus" OWNER TO postgres;

--
-- Name: WorkspacePermissionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WorkspacePermissionType" AS ENUM (
    'CREATE_TRANSACTION',
    'EDIT_TRANSACTION',
    'DELETE_TRANSACTION',
    'VIEW_REPORTS',
    'MANAGE_MEMBERS',
    'MANAGE_WORKSPACE',
    'ALL'
);


ALTER TYPE public."WorkspacePermissionType" OWNER TO postgres;

--
-- Name: WorkspaceRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WorkspaceRole" AS ENUM (
    'OWNER',
    'ADMIN',
    'MEMBER',
    'VIEWER'
);


ALTER TYPE public."WorkspaceRole" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _EmployeeToService; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_EmployeeToService" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_EmployeeToService" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addresses (
    id text NOT NULL,
    customer_id text NOT NULL,
    label text,
    is_default boolean DEFAULT false NOT NULL,
    type public."AddressType" DEFAULT 'SHIPPING'::public."AddressType" NOT NULL,
    recipient_name text NOT NULL,
    street text NOT NULL,
    number text NOT NULL,
    complement text,
    neighborhood text NOT NULL,
    city text NOT NULL,
    state text NOT NULL,
    zip_code text NOT NULL,
    country text DEFAULT 'BR'::text NOT NULL,
    latitude double precision,
    longitude double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.addresses OWNER TO postgres;

--
-- Name: analytics_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_events (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "eventType" text NOT NULL,
    "userId" text,
    "sessionId" text,
    "eventData" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.analytics_events OWNER TO postgres;

--
-- Name: analytics_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_reports (
    id text NOT NULL,
    "clientId" text NOT NULL,
    title text NOT NULL,
    description text,
    "reportType" text NOT NULL,
    period text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "fileUrl" text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    "generatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.analytics_reports OWNER TO postgres;

--
-- Name: annotations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.annotations (
    id text NOT NULL,
    client_id text NOT NULL,
    user_id text NOT NULL,
    employee_id text,
    created_by_id text NOT NULL,
    created_by_role public."UserRole" NOT NULL,
    appointment_id text,
    content text NOT NULL,
    visibility public."AnnotationVisibility" DEFAULT 'PRIVATE_TO_EMPLOYEE'::public."AnnotationVisibility" NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.annotations OWNER TO postgres;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id text NOT NULL,
    user_id text NOT NULL,
    employee_id text,
    service_id text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone NOT NULL,
    status public."AppointmentStatus" DEFAULT 'SCHEDULED'::public."AppointmentStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    client_id text NOT NULL
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    client_id text NOT NULL,
    user_id text,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    "oldValues" jsonb,
    "newValues" jsonb,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: budget_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_categories (
    id text NOT NULL,
    budget_id text NOT NULL,
    category_id text NOT NULL,
    amount numeric(12,2) NOT NULL,
    spent_amount numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.budget_categories OWNER TO postgres;

--
-- Name: budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budgets (
    id text NOT NULL,
    client_id text NOT NULL,
    workspace_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    period public."BudgetPeriod" NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    spent_amount numeric(12,2) DEFAULT 0 NOT NULL,
    status public."BudgetStatus" DEFAULT 'ACTIVE'::public."BudgetStatus" NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.budgets OWNER TO postgres;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    id text NOT NULL,
    cart_id text NOT NULL,
    product_id text NOT NULL,
    product_variant_id text,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    customizations jsonb DEFAULT '{}'::jsonb,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: carts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carts (
    id text NOT NULL,
    customer_id text NOT NULL,
    status public."CartStatus" DEFAULT 'ACTIVE'::public."CartStatus" NOT NULL,
    expires_at timestamp(3) without time zone,
    subtotal numeric(10,2) DEFAULT 0 NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    shipping numeric(10,2) DEFAULT 0 NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) DEFAULT 0 NOT NULL,
    coupon_id text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.carts OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    color text,
    type text
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    email text NOT NULL,
    phone text,
    logo text,
    website text,
    status public."ClientStatus" DEFAULT 'ACTIVE'::public."ClientStatus" NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    plan text DEFAULT 'basic'::text NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "activeServices" jsonb DEFAULT '[]'::jsonb NOT NULL,
    stripe_customer_id text
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: coupons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupons (
    id text NOT NULL,
    client_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    type public."CouponType" NOT NULL,
    value numeric(10,2) NOT NULL,
    min_amount numeric(10,2),
    max_discount numeric(10,2),
    usage_limit integer,
    used_count integer DEFAULT 0 NOT NULL,
    applicable_products text[] DEFAULT ARRAY[]::text[],
    applicable_categories text[] DEFAULT ARRAY[]::text[],
    starts_at timestamp(3) without time zone,
    expires_at timestamp(3) without time zone,
    is_active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.coupons OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id text NOT NULL,
    client_id text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    phone text,
    document text,
    birth_date timestamp(3) without time zone,
    gender public."Gender",
    password text,
    "isActive" boolean DEFAULT true NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    marketing_opt_in boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    last_login_at timestamp(3) without time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: doctor_appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor_appointments (
    id text NOT NULL,
    client_id text NOT NULL,
    doctor_id text NOT NULL,
    patient_id text NOT NULL,
    scheduled_at timestamp(3) without time zone NOT NULL,
    duration integer DEFAULT 30 NOT NULL,
    status public."AppointmentStatus" DEFAULT 'SCHEDULED'::public."AppointmentStatus" NOT NULL,
    symptoms text,
    diagnosis text,
    prescription text,
    notes text,
    price numeric(10,2) NOT NULL,
    "paymentStatus" public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.doctor_appointments OWNER TO postgres;

--
-- Name: doctors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctors (
    id text NOT NULL,
    client_id text NOT NULL,
    employee_id text NOT NULL,
    crm text NOT NULL,
    specialty text NOT NULL,
    sub_specialty text,
    consultation_duration integer DEFAULT 30 NOT NULL,
    consultation_price numeric(10,2) NOT NULL,
    schedule jsonb DEFAULT '{}'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.doctors OWNER TO postgres;

--
-- Name: ecommerce_order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ecommerce_order_items (
    id text NOT NULL,
    order_id text NOT NULL,
    product_id text NOT NULL,
    product_variant_id text,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    product_name text NOT NULL,
    product_image text,
    product_sku text,
    customizations jsonb DEFAULT '{}'::jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ecommerce_order_items OWNER TO postgres;

--
-- Name: ecommerce_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ecommerce_orders (
    id text NOT NULL,
    client_id text NOT NULL,
    customer_id text NOT NULL,
    order_number text NOT NULL,
    status public."EcommerceOrderStatus" DEFAULT 'PENDING'::public."EcommerceOrderStatus" NOT NULL,
    shipping_address_id text,
    billing_address_id text,
    subtotal numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    shipping_cost numeric(10,2) DEFAULT 0 NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    payment_status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    payment_method text,
    shipping_method text,
    tracking_code text,
    estimated_delivery timestamp(3) without time zone,
    delivered_at timestamp(3) without time zone,
    coupon_id text,
    coupon_discount numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    internal_notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    confirmed_at timestamp(3) without time zone,
    shipped_at timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone
);


ALTER TABLE public.ecommerce_orders OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id text NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    avatar text,
    "position" text NOT NULL,
    description text,
    "workingHours" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    user_id text NOT NULL
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: financial_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financial_goals (
    id text NOT NULL,
    client_id text NOT NULL,
    workspace_id text,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    target_amount numeric(12,2) NOT NULL,
    current_amount numeric(12,2) DEFAULT 0 NOT NULL,
    category text,
    target_date timestamp(3) without time zone,
    status public."GoalStatus" DEFAULT 'ACTIVE'::public."GoalStatus" NOT NULL,
    priority public."GoalPriority" DEFAULT 'MEDIUM'::public."GoalPriority" NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.financial_goals OWNER TO postgres;

--
-- Name: frontend_cache_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.frontend_cache_metadata (
    id text NOT NULL,
    client_id text NOT NULL,
    cache_key text NOT NULL,
    last_updated timestamp(3) without time zone NOT NULL,
    version text,
    data_size integer,
    hit_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.frontend_cache_metadata OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    order_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "totalPrice" numeric(10,2) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    client_id text NOT NULL,
    user_id text NOT NULL,
    "orderNumber" text NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    total numeric(10,2) NOT NULL,
    "deliveryAddress" text,
    "deliveryFee" numeric(10,2),
    "paymentStatus" public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "paymentMethod" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patients (
    id text NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text NOT NULL,
    document text,
    birth_date timestamp(3) without time zone,
    gender public."Gender",
    address text,
    city text,
    state text,
    zip_code text,
    blood_type text,
    allergies text,
    medications text,
    medical_history text,
    emergency_contact text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.patients OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    client_id text NOT NULL,
    customer_id text NOT NULL,
    order_id text,
    payment_number text NOT NULL,
    method public."PaymentMethod" NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    gateway text,
    gateway_id text,
    gateway_data jsonb,
    pix_key text,
    pix_qr_code text,
    card_last4 text,
    card_brand text,
    installments integer DEFAULT 1 NOT NULL,
    due_date timestamp(3) without time zone,
    paid_at timestamp(3) without time zone,
    failed_at timestamp(3) without time zone,
    refunded_at timestamp(3) without time zone,
    notes text,
    failure_reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_variants (
    id text NOT NULL,
    product_id text NOT NULL,
    name text NOT NULL,
    sku text,
    size text,
    color text,
    material text,
    attributes jsonb DEFAULT '{}'::jsonb,
    price numeric(10,2),
    compare_price numeric(10,2),
    stock integer DEFAULT 0 NOT NULL,
    images text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.product_variants OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    client_id text NOT NULL,
    category_id text,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    sku text,
    stock integer DEFAULT 0 NOT NULL,
    "minStock" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isFeatured" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    images text[] DEFAULT ARRAY[]::text[]
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.properties (
    id text NOT NULL,
    client_id text NOT NULL,
    title text NOT NULL,
    description text,
    type public."PropertyType" NOT NULL,
    status public."PropertyStatus" DEFAULT 'AVAILABLE'::public."PropertyStatus" NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    state text NOT NULL,
    zip_code text NOT NULL,
    neighborhood text,
    bedrooms integer,
    bathrooms integer,
    area numeric(10,2),
    parking_spots integer,
    price numeric(12,2) NOT NULL,
    "rentPrice" numeric(10,2),
    condo_fee numeric(10,2),
    iptu numeric(10,2),
    images jsonb DEFAULT '[]'::jsonb NOT NULL,
    virtual_360 text,
    amenities jsonb DEFAULT '[]'::jsonb NOT NULL,
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.properties OWNER TO postgres;

--
-- Name: property_leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.property_leads (
    id text NOT NULL,
    property_id text NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    message text,
    source text,
    status public."LeadStatus" DEFAULT 'NEW'::public."LeadStatus" NOT NULL,
    priority public."LeadPriority" DEFAULT 'MEDIUM'::public."LeadPriority" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.property_leads OWNER TO postgres;

--
-- Name: property_visits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.property_visits (
    id text NOT NULL,
    property_id text NOT NULL,
    client_id text NOT NULL,
    visitor_name text NOT NULL,
    visitor_email text NOT NULL,
    visitor_phone text NOT NULL,
    scheduled_at timestamp(3) without time zone NOT NULL,
    status public."VisitStatus" DEFAULT 'SCHEDULED'::public."VisitStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.property_visits OWNER TO postgres;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id text NOT NULL,
    product_id text NOT NULL,
    customer_id text NOT NULL,
    order_id text,
    rating integer NOT NULL,
    title text,
    comment text,
    images text[] DEFAULT ARRAY[]::text[],
    is_published boolean DEFAULT false NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    response text,
    responded_at timestamp(3) without time zone,
    helpful_count integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedules (
    id text NOT NULL,
    client_id text NOT NULL,
    user_id text NOT NULL,
    employee_id text,
    date timestamp(3) without time zone NOT NULL,
    title text NOT NULL,
    description text,
    tasks jsonb DEFAULT '[]'::jsonb NOT NULL,
    status public."ScheduleStatus" DEFAULT 'PENDING'::public."ScheduleStatus" NOT NULL,
    priority public."SchedulePriority" DEFAULT 'MEDIUM'::public."SchedulePriority" NOT NULL,
    start_time timestamp(3) without time zone,
    end_time timestamp(3) without time zone,
    all_day boolean DEFAULT false NOT NULL,
    is_recurring boolean DEFAULT false NOT NULL,
    recurring_pattern jsonb,
    color text,
    category public."ScheduleCategory" DEFAULT 'WORK'::public."ScheduleCategory" NOT NULL,
    reminders jsonb DEFAULT '[]'::jsonb NOT NULL,
    attachments text[] DEFAULT ARRAY[]::text[],
    is_public boolean DEFAULT false NOT NULL,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.schedules OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    duration integer NOT NULL,
    price numeric(10,2) NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    category_id text,
    client_id text NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: shared_data_audit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shared_data_audit (
    id text NOT NULL,
    client_id text NOT NULL,
    workspace_id text,
    user_id text NOT NULL,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text NOT NULL,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.shared_data_audit OWNER TO postgres;

--
-- Name: shipment_trackings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipment_trackings (
    id text NOT NULL,
    shipment_id text NOT NULL,
    status text NOT NULL,
    message text NOT NULL,
    location text,
    datetime timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.shipment_trackings OWNER TO postgres;

--
-- Name: shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipments (
    id text NOT NULL,
    order_id text NOT NULL,
    tracking_code text,
    method text NOT NULL,
    status public."ShipmentStatus" DEFAULT 'PREPARING'::public."ShipmentStatus" NOT NULL,
    weight double precision,
    width double precision,
    height double precision,
    length double precision,
    cost numeric(10,2),
    estimated_delivery timestamp(3) without time zone,
    shipped_at timestamp(3) without time zone,
    delivered_at timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.shipments OWNER TO postgres;

--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    client_id text NOT NULL,
    product_id text NOT NULL,
    user_id text NOT NULL,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    unit_cost numeric(10,2),
    total_cost numeric(10,2),
    order_id text,
    supplier_id text,
    batch_number text,
    expiry_date timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    document text,
    email text,
    phone text,
    address text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    client_id text NOT NULL,
    workspace_id text,
    user_id text NOT NULL,
    category_id text,
    title text NOT NULL,
    description text,
    amount numeric(12,2) NOT NULL,
    type public."TransactionType" NOT NULL,
    status public."TransactionStatus" DEFAULT 'CONFIRMED'::public."TransactionStatus" NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    is_recurring boolean DEFAULT false NOT NULL,
    recurring_pattern jsonb,
    tags text[] DEFAULT ARRAY[]::text[],
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    avatar text,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'CLIENT'::public."UserRole" NOT NULL,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    "failedLoginAttempts" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "lastLogin" timestamp(3) without time zone,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "emailVerificationToken" text,
    "passwordResetToken" text,
    "passwordResetTokenExpiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    employee_id text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: wishlist_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wishlist_items (
    id text NOT NULL,
    wishlist_id text NOT NULL,
    product_id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.wishlist_items OWNER TO postgres;

--
-- Name: wishlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wishlists (
    id text NOT NULL,
    customer_id text NOT NULL,
    name text DEFAULT 'Minha Lista'::text NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.wishlists OWNER TO postgres;

--
-- Name: workspace_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workspace_members (
    id text NOT NULL,
    workspace_id text NOT NULL,
    user_id text NOT NULL,
    role public."WorkspaceRole" DEFAULT 'MEMBER'::public."WorkspaceRole" NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.workspace_members OWNER TO postgres;

--
-- Name: workspace_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workspace_notifications (
    id text NOT NULL,
    client_id text NOT NULL,
    workspace_id text,
    user_id text NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.workspace_notifications OWNER TO postgres;

--
-- Name: workspace_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workspace_permissions (
    id text NOT NULL,
    workspace_id text NOT NULL,
    member_id text NOT NULL,
    permission public."WorkspacePermissionType" NOT NULL,
    granted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    granted_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.workspace_permissions OWNER TO postgres;

--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workspaces (
    id text NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    description text,
    is_public boolean DEFAULT false NOT NULL,
    created_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.workspaces OWNER TO postgres;

--
-- Data for Name: _EmployeeToService; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_EmployeeToService" ("A", "B") FROM stdin;
0a05bfe7-fc10-44fe-85bd-bc0544944c0a	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
1d97c7bb-e720-4c04-a251-bb9343eba546	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
241d6e85-1a16-45cd-94c1-fb1e5fdad28b	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
2c4b2f18-8788-42aa-a91d-5d3495b86d87	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
307f6e5c-b314-4a3c-92e6-84364dc8eab0	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
40603111-2abe-4847-86fb-46e684fd7c32	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
48d062be-5d0a-4211-849e-15dbb8b3b296	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
5cf13adf-483a-4967-add4-d830509386fc	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
624659b3-9523-47ff-ae65-f82d4f292464	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
7c364568-2cfc-4b11-a925-3e048ee2282c	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
7f6759af-9863-493d-b4d9-3fc7f27ce627	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
85cb2fba-fc32-4bcc-bc49-0e773c973f2a	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
8d23d3b8-6e20-4578-a503-07e9e2a2dcd6	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
a055bb1b-8880-4799-adf7-4fe462968169	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
a33bd12f-0975-4cff-bc76-b44e6ef20d82	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
a7e76494-1e3d-424a-8730-75dea10bbdb1	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
c1919450-b3d3-4aeb-9366-d85419a8e0ca	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
c74c3663-0edb-445d-a7c1-ebffc4e801f0	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
ebd9a8a0-711e-4052-a73e-9309f8aa4531	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
efd2f305-7f3b-47cb-9a54-543993946044	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
f0c243dc-cb38-448a-a8d1-4237884cc67f	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
f9043087-dd32-4928-8690-ed149c0094ca	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
fb96675d-7fb5-4ad1-850f-9af414743dc6	e19b26f7-6a38-4bf0-8e98-34deb4c5aaea
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
48bce698-f869-4da5-8d77-a3b704d566c6	58b2a0607de69cc86d078fc4d84f19d8e9b7eb5a6162af3d84bfcf5018e8aed6	2025-08-09 23:54:53.822546+00	20250809235453_add_annotations	\N	\N	2025-08-09 23:54:53.744536+00	1
4d7a75cf-1ebf-470b-84dc-0e3f3eab395e	ca4977d634e9a09fcb0bc243fe19bfba30d6eb03ca35734bd53e954e411d1953	2025-08-08 14:31:41.713439+00	20250619234952_init	\N	\N	2025-08-08 14:31:41.127383+00	1
71e068da-50b0-4fd0-bbd1-eee50c79ed14	a2d4616c9fd5e2e8788fc17cfc8c40e69a6d54b14578337c5671432c607fe385	2025-08-08 14:31:42.218556+00	20250621190141_add_multi_tenant_extensions	\N	\N	2025-08-08 14:31:41.728022+00	1
4266491b-3400-4f9f-bd7f-4500e8477a63	5dc0f62bd1a2c1d59f76a96e2e92a4841a7e22fc571b0e31866d78391dc1a810	2025-08-08 14:31:42.907424+00	20250625202810_caralhowww	\N	\N	2025-08-08 14:31:42.236324+00	1
d9b33146-8c6d-4686-9ec5-271b5e11b518	27613615422d65cb1d01183e9fc83ea9cc2c6ea433ba739893d1f9a5e58876b0	2025-08-31 14:35:51.610567+00	20250831143551_add_schedule_table	\N	\N	2025-08-31 14:35:51.420362+00	1
0a633e60-5223-4689-b919-ecc109228b50	a874f9a5911b8496ae6f1df7e43f17b4437c19bbee2a4d4f533d3bc68b76f4f5	2025-08-08 14:31:42.97723+00	20250626114229_ajuste_services_appointments	\N	\N	2025-08-08 14:31:42.922547+00	1
94ed9453-c9bc-4dd8-8a69-92a872705346	f86777499840f4a97247b43fde6bd2ddcc6a26e7b2aeed9912a5ba6f90540b04	2025-08-08 14:31:43.051894+00	20250627063215_recreate_services_and_appointments_with_client_id	\N	\N	2025-08-08 14:31:42.999868+00	1
0a20f27c-9a54-45c9-89c3-cf66546be126	ae667c87cbe8f1bbbc6234c5ca89f542609d7e71905108255b978271ee20c2d4	2025-08-08 14:31:43.432893+00	20250801144703_remove_notes_from_appointments	\N	\N	2025-08-08 14:31:43.076246+00	1
8f6af58c-5127-4346-b3fb-ea328182f431	afe3be140d728228ba07fb1fd55d0f0eddac3e40c7049b1ae0622e3893d9cac5	2025-09-25 18:09:05.836073+00	20250925180905_add_workspace_finance_module	\N	\N	2025-09-25 18:09:05.31916+00	1
c6efc60b-3853-4d08-9d91-22eb71ef696e	8edc94f45ece7dc92b2538846bd9c2797acdfc01fd5c3f9f32d14c16bb58a4d2	2025-08-08 14:31:43.506114+00	20250805153513_add_password_to_employees	\N	\N	2025-08-08 14:31:43.453315+00	1
1106a8cd-eda5-4cdf-9685-2089b50e6267	4751919d6cf9e8618fc89da935a929eeb6fffc60910b7da6619cb0cd5af0c80c	2025-08-08 14:31:43.626669+00	20250808120000_add_userid_to_employees	\N	\N	2025-08-08 14:31:43.527103+00	1
7d205b64-9fb6-498d-800f-1f1b3c52a0ef	584dfd90532269aece3750ffa8fed574f8fdda204e62b257644bb28f2a679df4	2025-08-08 14:31:43.694763+00	20250808131000_add_userid_to_employees_fix	\N	\N	2025-08-08 14:31:43.644504+00	1
1a4c2fa9-ee79-4974-a559-04bb6f66897c	0df4bb57b0acc50e45b94c041d954a9040ca7b9e260d71c6eac9476d9214fc5d	2025-10-05 01:25:30.767041+00	20251005012530_add_active_services_to_client	\N	\N	2025-10-05 01:25:30.731269+00	1
76adcb55-134c-4c3f-a26c-46024f5e4f0b	89906dae9cc870a0c6a55b1829b4bea6854024dcf19891b5c1d4b61c5f2b542f	2025-08-08 14:31:43.792732+00	20250808132000_add_userid_to_employees_fix	\N	\N	2025-08-08 14:31:43.713489+00	1
7c9eec6d-fdf1-432a-9ec0-b9db2d58967f	9a7f183ee643880ae6100e5d485dfa3fbf0d6cc038a2dec9c156e2a6e63036c5	2025-08-08 14:31:50.129709+00	20250808143149_add_userid_to_employees_fix	\N	\N	2025-08-08 14:31:50.072943+00	1
e67f37aa-021c-4832-96f6-1ba218a44d50	0f538328e9436557e1cc0e86e7ef2aa1f021151e78498aa3ae7637fb4f8f4d61	2025-08-09 14:11:32.545687+00	20250809141132_add_employee_id_to_users	\N	\N	2025-08-09 14:11:32.353066+00	1
ade07711-25ed-4d2c-9902-8a3a8dc8dc35	8fd2c301e457729b87e409cd0c8b090763ff855933eeb2eab1fca84956013480	2025-10-06 11:44:18.745767+00	20251006114418_add_analytics_tables	\N	\N	2025-10-06 11:44:18.565097+00	1
0e3860ad-4e0a-4151-97f9-6028b3d65b33	db991a81ab6ceed51ff03ca5d4187308f28258a910302934022a38d8bf689d48	2025-10-10 00:06:50.482677+00	20251010000650_add_stripe_customer_id	\N	\N	2025-10-10 00:06:50.44059+00	1
\.


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addresses (id, customer_id, label, is_default, type, recipient_name, street, number, complement, neighborhood, city, state, zip_code, country, latitude, longitude, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: analytics_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_events (id, "clientId", "eventType", "userId", "sessionId", "eventData", "timestamp", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: analytics_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_reports (id, "clientId", title, description, "reportType", period, status, "fileUrl", metadata, "generatedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: annotations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.annotations (id, client_id, user_id, employee_id, created_by_id, created_by_role, appointment_id, content, visibility, is_pinned, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (id, user_id, employee_id, service_id, "startTime", "endTime", status, "createdAt", "updatedAt", client_id) FROM stdin;
86c28cc2-01cd-4c32-8238-c08f0bf555f2	2496b194-40ff-4c3a-bc54-a226e060f70f	\N	daed6449-6ced-4ea0-a1a4-510cfb3064ca	2025-10-15 10:45:00	2025-10-15 11:45:00	NO_SHOW	2025-10-07 22:11:56.899	2025-10-07 22:11:56.899	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
c9a754f6-0fe4-4971-9567-cbe2a380ee1b	eb9e4918-ee78-46f0-903c-d515fd166a49	\N	ce43d141-7230-4f4f-a3ff-21b1b45a1af0	2025-09-24 08:00:00	2025-09-24 09:00:00	NO_SHOW	2025-10-07 22:11:56.907	2025-10-07 22:11:56.907	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
eb283adb-7ac8-486b-8ec7-a526738be588	eacf8450-1ad5-43fa-bb53-dada7ef2b95f	\N	daed6449-6ced-4ea0-a1a4-510cfb3064ca	2025-09-23 15:15:00	2025-09-23 16:15:00	CANCELLED	2025-10-07 22:11:56.913	2025-10-07 22:11:56.913	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
b8d4204b-6a47-4bd8-a223-a1b3b40f6181	6758c63d-238d-446e-ad34-eafe4cc56eb8	\N	3964fcc6-b5bf-4be5-b3c2-bfca76284f5c	2025-09-22 13:30:00	2025-09-22 14:20:00	SCHEDULED	2025-10-07 22:11:56.92	2025-10-07 22:11:56.92	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
1fa41de4-382e-4f90-a8aa-67986e45b6e6	d0ee3f0f-2c4b-48b3-b92c-6a4cc26ffd63	\N	32d39247-a92e-4fe0-b5e6-b1051a594906	2025-10-21 14:15:00	2025-10-21 15:15:00	CANCELLED	2025-10-07 22:11:56.929	2025-10-07 22:11:56.929	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
5c55acf5-ecfb-42b3-9b37-f67afb8edb3c	6d87eccb-b1eb-4c4e-b255-991deb0629bf	\N	3964fcc6-b5bf-4be5-b3c2-bfca76284f5c	2025-10-03 10:45:00	2025-10-03 11:35:00	IN_PROGRESS	2025-10-07 22:11:56.936	2025-10-07 22:11:56.936	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
db82d530-34cf-453c-a032-b23f8a933161	bb0844a4-5cc7-4f10-8121-2f5a5a8c73ff	\N	32d39247-a92e-4fe0-b5e6-b1051a594906	2025-10-01 10:45:00	2025-10-01 11:45:00	SCHEDULED	2025-10-07 22:11:56.94	2025-10-07 22:11:56.94	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
7f5e3c9f-4b0c-4843-ab3b-cb75eb20ef2b	11041e62-05b3-4c8c-b34b-09dc03383219	\N	daed6449-6ced-4ea0-a1a4-510cfb3064ca	2025-09-25 11:45:00	2025-09-25 12:45:00	CANCELLED	2025-10-07 22:11:56.945	2025-10-07 22:11:56.945	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
f48c0fee-6497-4249-844e-13bf6a2485af	6758c63d-238d-446e-ad34-eafe4cc56eb8	\N	daed6449-6ced-4ea0-a1a4-510cfb3064ca	2025-10-21 14:00:00	2025-10-21 15:00:00	NO_SHOW	2025-10-07 22:11:56.949	2025-10-07 22:11:56.949	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
138d5e15-5ab1-4c71-9007-49910ce9e687	eacf8450-1ad5-43fa-bb53-dada7ef2b95f	\N	3856e12e-7eeb-4029-9f79-9b2d2fb05b07	2025-09-22 08:30:00	2025-09-22 09:45:00	NO_SHOW	2025-10-07 22:11:56.953	2025-10-07 22:11:56.953	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
4c82f6eb-595f-4803-ada5-502049aa28fd	6d87eccb-b1eb-4c4e-b255-991deb0629bf	\N	451d01ca-5705-4c76-a58c-bd24bf3e6fa2	2025-09-30 09:30:00	2025-09-30 10:20:00	COMPLETED	2025-10-07 22:11:56.957	2025-10-07 22:11:56.957	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
e2e6bcf5-b7b1-43e2-992c-487915c78407	78552b31-6316-4f78-8122-62bcc464a9df	\N	3856e12e-7eeb-4029-9f79-9b2d2fb05b07	2025-10-08 14:00:00	2025-10-08 15:15:00	CONFIRMED	2025-10-07 22:11:56.962	2025-10-07 22:11:56.962	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
fd67300b-c9dc-4e98-ab77-96179f70425e	c550cdde-f93f-4c98-8fbd-a1674db077ab	\N	3964fcc6-b5bf-4be5-b3c2-bfca76284f5c	2025-10-13 11:30:00	2025-10-13 12:20:00	NO_SHOW	2025-10-07 22:11:56.966	2025-10-07 22:11:56.966	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
6cff2ca5-59f9-49b5-b9ee-27c776bd5c75	0926ad32-cb18-4e0e-a66e-c4eb3a6f1a93	\N	daed6449-6ced-4ea0-a1a4-510cfb3064ca	2025-10-13 08:45:00	2025-10-13 09:45:00	CANCELLED	2025-10-07 22:11:56.971	2025-10-07 22:11:56.971	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
3ce3a359-28e0-4f36-98b0-882f517128a2	22139cfd-dba9-4981-8d2d-6e962af4421e	\N	3856e12e-7eeb-4029-9f79-9b2d2fb05b07	2025-10-09 09:00:00	2025-10-09 10:15:00	CONFIRMED	2025-10-07 22:11:56.975	2025-10-07 22:11:56.975	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
6398e066-f072-4876-8c99-c49e0ae42dcb	4c03ab93-4098-4b7a-84af-900ab2633191	\N	3964fcc6-b5bf-4be5-b3c2-bfca76284f5c	2025-10-09 11:30:00	2025-10-09 12:20:00	NO_SHOW	2025-10-07 22:11:56.98	2025-10-07 22:11:56.98	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
695bade0-df6d-4a38-8a98-b04211f22388	4c03ab93-4098-4b7a-84af-900ab2633191	\N	3856e12e-7eeb-4029-9f79-9b2d2fb05b07	2025-10-02 13:30:00	2025-10-02 14:45:00	IN_PROGRESS	2025-10-07 22:11:56.984	2025-10-07 22:11:56.984	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
f0a6954d-3961-4314-b714-f25505e7a620	eb9e4918-ee78-46f0-903c-d515fd166a49	\N	32d39247-a92e-4fe0-b5e6-b1051a594906	2025-10-14 13:45:00	2025-10-14 14:45:00	CONFIRMED	2025-10-07 22:11:56.988	2025-10-07 22:11:56.988	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
aa0ddc52-0fa2-4c79-a1e5-5090ac56a658	78552b31-6316-4f78-8122-62bcc464a9df	\N	eec9720a-84ab-4e54-a80b-3d283bd9ebbc	2025-09-28 13:00:00	2025-09-28 14:30:00	COMPLETED	2025-10-07 22:11:56.991	2025-10-07 22:11:56.991	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
157e4772-46b1-4c04-8c30-b67d555520c1	c70a6af5-6796-498e-8db8-0f45d46e79e9	\N	3856e12e-7eeb-4029-9f79-9b2d2fb05b07	2025-10-20 15:15:00	2025-10-20 16:30:00	CONFIRMED	2025-10-07 22:11:56.995	2025-10-07 22:11:56.995	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, client_id, user_id, action, entity, entity_id, "oldValues", "newValues", "ipAddress", "userAgent", "createdAt") FROM stdin;
\.


--
-- Data for Name: budget_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_categories (id, budget_id, category_id, amount, spent_amount, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budgets (id, client_id, workspace_id, user_id, name, description, period, start_date, end_date, total_amount, spent_amount, status, is_public, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (id, cart_id, product_id, product_variant_id, quantity, unit_price, total_price, customizations, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carts (id, customer_id, status, expires_at, subtotal, discount, shipping, tax, total, coupon_id, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, client_id, name, description, "isActive", "createdAt", "updatedAt", color, type) FROM stdin;
30d50b8a-5d7f-4be9-a364-4fb70c4abded	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Psicanálise	Categoria de serviços de psicanálise	t	2025-08-26 15:11:34.93	2025-08-26 15:11:34.93	#01386F	\N
f44d19a0-943a-408c-9207-943c8312d3c3	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.73	2025-10-07 22:11:55.73	\N	\N
573f1ab5-fed7-463a-b24d-008453049241	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.768	2025-10-07 22:11:55.768	\N	\N
93d85031-284e-43ff-a0d3-22b740498f05	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.777	2025-10-07 22:11:55.777	\N	\N
9bc9ccf0-8d63-4f0b-814b-3c00be9f89cc	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.784	2025-10-07 22:11:55.784	\N	\N
5c0075f5-40fa-4cd0-918a-7a3c363e7257	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.791	2025-10-07 22:11:55.791	\N	\N
3d041e0d-8d0b-481d-8d17-ee60dd323818	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.797	2025-10-07 22:11:55.797	\N	\N
351cfdc5-ef83-4ae1-be37-413a49acf4e4	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.804	2025-10-07 22:11:55.804	\N	\N
fc1ddd56-4614-4dc6-aab8-d3498c8608d8	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.811	2025-10-07 22:11:55.811	\N	\N
089e6a8a-f650-4ac2-a927-a7fb2c24663e	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.819	2025-10-07 22:11:55.819	\N	\N
2465789c-11b4-49e0-a587-9f9676680a6b	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.825	2025-10-07 22:11:55.825	\N	\N
ee83a168-cdf6-4d68-9a6b-44e566ff6c1f	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.832	2025-10-07 22:11:55.832	\N	\N
866fc547-83ee-4f6f-92e1-17dcf5f6b5be	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.839	2025-10-07 22:11:55.839	\N	\N
e741bf8a-c6a6-4b63-8240-a4e27feb4611	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.847	2025-10-07 22:11:55.847	\N	\N
ffb95baa-2d64-48f0-9bc2-4202636079f2	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.854	2025-10-07 22:11:55.854	\N	\N
5ed91df4-1dc7-4de2-b79c-165293c82ccd	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.86	2025-10-07 22:11:55.86	\N	\N
93b97878-8d73-42cd-8a0d-4687ad3b8c1c	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.866	2025-10-07 22:11:55.866	\N	\N
35bf6ebe-3104-4618-9113-9597a0da0591	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.873	2025-10-07 22:11:55.873	\N	\N
69c7c5ed-fd2a-46c7-8299-19ac87386bda	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.879	2025-10-07 22:11:55.879	\N	\N
cdaf5cfc-44ca-4fba-a2a3-c7274be01008	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.886	2025-10-07 22:11:55.886	\N	\N
5b584896-d565-4f80-b8f0-1475c09e0d89	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Suplementos	Categoria de suplementos	t	2025-10-07 22:11:55.893	2025-10-07 22:11:55.893	\N	\N
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, name, slug, email, phone, logo, website, status, settings, plan, "expiresAt", "createdAt", "updatedAt", "activeServices", stripe_customer_id) FROM stdin;
fff6a743-2689-4a31-b9db-9098bcccfd27	UltraDashboard Creator	ultradashboard-creator	guillermo@ultradashboard.com	+55 11 99999-9999	\N	https://ultradashboard.com	ACTIVE	{}	enterprise	\N	2025-10-04 13:45:36.872	2025-10-04 13:45:36.872	[]	\N
2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Expatriamente	expatriamente	contato@expatriamente.com	\N	\N	\N	ACTIVE	{}	premium	\N	2025-08-26 15:11:34.338	2025-08-26 15:11:34.338	["Users", "Employees", "Appointments"]	\N
4a2d7176-3f9d-43da-9a7f-e97d08f54744	BemMeCare	bemmecare	contato@bemmecare.com	(11) 99999-9999			ACTIVE	{"theme": "blue", "features": ["appointments", "ecommerce", "reports"]}	premium	\N	2025-09-25 23:58:51.145	2025-09-25 23:58:51.145	["Users", "Ecommerce", "Finance", "Schedule"]	\N
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupons (id, client_id, code, name, description, type, value, min_amount, max_discount, usage_limit, used_count, applicable_products, applicable_categories, starts_at, expires_at, is_active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, client_id, first_name, last_name, email, phone, document, birth_date, gender, password, "isActive", "emailVerified", preferences, marketing_opt_in, "createdAt", "updatedAt", last_login_at) FROM stdin;
\.


--
-- Data for Name: doctor_appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor_appointments (id, client_id, doctor_id, patient_id, scheduled_at, duration, status, symptoms, diagnosis, prescription, notes, price, "paymentStatus", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctors (id, client_id, employee_id, crm, specialty, sub_specialty, consultation_duration, consultation_price, schedule, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ecommerce_order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ecommerce_order_items (id, order_id, product_id, product_variant_id, quantity, unit_price, total_price, product_name, product_image, product_sku, customizations, "createdAt") FROM stdin;
\.


--
-- Data for Name: ecommerce_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ecommerce_orders (id, client_id, customer_id, order_number, status, shipping_address_id, billing_address_id, subtotal, discount, shipping_cost, tax, total, payment_status, payment_method, shipping_method, tracking_code, estimated_delivery, delivered_at, coupon_id, coupon_discount, notes, internal_notes, "createdAt", "updatedAt", confirmed_at, shipped_at, cancelled_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, client_id, name, email, phone, avatar, "position", description, "workingHours", "isActive", "createdAt", "updatedAt", user_id) FROM stdin;
c1919450-b3d3-4aeb-9366-d85419a8e0ca	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Tacyana Salomão	tacyana.salomao@expatriamente.com	(11) 91236-8270	/funcionarios/Tacyana Salomão - Psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Consegue disponibilizar estes horários a partir de Agosto/2025. Introdução à Escuta Psicanalítica - SOCIEDADE BRASILEIRA DE PSICANÁLISE, São Paulo. Sándor Ferenczi - GRUPO ESTUDOS DANIEL KUPPERMANN, São Paulo. Escuta da Subjetividade IPO – HOSPITAL DAS CLÍNICAS, São Paulo. Psicanálise Clínica - CENTRO DE PSICANÁLISE WC, Campinas. Psicanálise, Pós Graduação FAATESP, Campinas. Atendimento pacientes entre 15 a 80 anos – homem ou mulher.	{"timeOffs": [], "timeSlots": [{"id": "slot_3_0900_0", "endTime": "10:00", "isActive": true, "dayOfWeek": 3, "startTime": "09:00", "isRecurring": true}, {"id": "slot_3_1000_1", "endTime": "11:00", "isActive": true, "dayOfWeek": 3, "startTime": "10:00", "isRecurring": true}, {"id": "slot_3_1600_2", "endTime": "17:00", "isActive": true, "dayOfWeek": 3, "startTime": "16:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.894	2025-09-05 15:37:09.674	a480f5f8-9be3-461d-879d-52e8c05bddb3
f9043087-dd32-4928-8690-ed149c0094ca	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Gabriela Reis	gabriela.reis@expatriamente.com	(11)99613-3022	/funcionarios/Gabriela Reis - Psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Fonoaudiologia pela Universidade do Norte Paulista, Gestão Financeira pela Fundação Getúlio Vargas, Psicanálise pelo Centro de Formação em Psicanálise Clínica. Público Alvo: Pacientes acima de 18 anos.	{"timeOffs": [], "timeSlots": []}	t	2025-08-26 15:11:34.705	2025-09-05 15:22:56.748	f3859b39-51dd-496e-b4fc-332457dbfab1
c74c3663-0edb-445d-a7c1-ebffc4e801f0	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Ademir Fragnani Jr	ademir.fragnani.jr@expatriamente.com	(19) 99999-8880	/funcionarios/Ademir Fragnani Junior.jpg	Psicanalista Clínico	Psicanalista Clínico com experiência anterior no mundo corporativo. Atua principalmente com adultos, abordando temas como burnout, gestão e transição de carreira, crises de meia idade e relacionamentos. Com mais de 25 anos em posições de Alta Gerência em empresas multinacionais, conhece bem a cultura e o clima dessas organizações, tendo tido reconhecida atuação na gestão de pessoas nesses ambientes. Leva sua vivência para a prática clínica do mundo afora, sempre focando em uma abordagem não só de entendimento, mas de reflexões e novas perspectivas para as demandas de seus pacientes. Inglês fluente, espanhol intermediário. Casado, teve três filhas que fizeram intercâmbio, sendo uma residente no exterior por sete anos.	{"timeOffs": [], "timeSlots": [{"id": "slot_2_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 2, "startTime": "08:00", "isRecurring": true}, {"id": "slot_2_1000_1", "endTime": "11:00", "isActive": true, "dayOfWeek": 2, "startTime": "10:00", "isRecurring": true}, {"id": "slot_2_1600_2", "endTime": "17:00", "isActive": true, "dayOfWeek": 2, "startTime": "16:00", "isRecurring": true}, {"id": "slot_2_1930_3", "endTime": "20:30", "isActive": true, "dayOfWeek": 2, "startTime": "19:30", "isRecurring": true}, {"id": "slot_6_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 6, "startTime": "10:00", "isRecurring": true}, {"id": "slot_6_1400_1", "endTime": "15:00", "isActive": true, "dayOfWeek": 6, "startTime": "14:00", "isRecurring": true}, {"id": "slot_6_1800_2", "endTime": "19:00", "isActive": true, "dayOfWeek": 6, "startTime": "18:00", "isRecurring": true}, {"id": "slot_4_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 4, "startTime": "08:00", "isRecurring": true}, {"id": "slot_4_1000_1", "endTime": "11:00", "isActive": true, "dayOfWeek": 4, "startTime": "10:00", "isRecurring": true}, {"id": "slot_4_1200_2", "endTime": "13:00", "isActive": true, "dayOfWeek": 4, "startTime": "12:00", "isRecurring": true}, {"id": "slot_4_1930_3", "endTime": "20:30", "isActive": true, "dayOfWeek": 4, "startTime": "19:30", "isRecurring": true}]}	t	2025-08-26 15:11:34.588	2025-09-05 15:37:09.47	bd2dc514-2191-4837-8e98-f94459676b6e
a33bd12f-0975-4cff-bc76-b44e6ef20d82	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Laura Truzzi	laura.truzzi@expatriamente.com	(11) 99580-4327	/funcionarios/Laura Truzzi - Psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Nome: Laura Truzzi Guyot. Formação: Comunicação Social (graduação) e pós em Gestão de Pessoas. Analista Disc. Practiner em PNL. Coaching - SBC. Psicanálise - CFPC. Pós em Psicanálise - CFPC. ADI - CFPC. Psicanálise Infantil - CFPC.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_1200_0", "endTime": "13:00", "isActive": true, "dayOfWeek": 5, "startTime": "12:00", "isRecurring": true}, {"id": "slot_2_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 2, "startTime": "10:00", "isRecurring": true}, {"id": "slot_2_1100_1", "endTime": "12:00", "isActive": true, "dayOfWeek": 2, "startTime": "11:00", "isRecurring": true}, {"id": "slot_2_1300_2", "endTime": "14:00", "isActive": true, "dayOfWeek": 2, "startTime": "13:00", "isRecurring": true}, {"id": "slot_6_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 6, "startTime": "10:00", "isRecurring": true}, {"id": "slot_4_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 4, "startTime": "10:00", "isRecurring": true}, {"id": "slot_4_1100_1", "endTime": "12:00", "isActive": true, "dayOfWeek": 4, "startTime": "11:00", "isRecurring": true}, {"id": "slot_4_1200_2", "endTime": "13:00", "isActive": true, "dayOfWeek": 4, "startTime": "12:00", "isRecurring": true}, {"id": "slot_3_1100_0", "endTime": "12:00", "isActive": true, "dayOfWeek": 3, "startTime": "11:00", "isRecurring": true}, {"id": "slot_3_1200_1", "endTime": "13:00", "isActive": true, "dayOfWeek": 3, "startTime": "12:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.765	2025-09-05 15:37:09.483	8ccb5d5c-2c27-4502-ac36-17cf59ebe374
a7e76494-1e3d-424a-8730-75dea10bbdb1	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Carlos Henrique Mathias	carlos.henrique.mathias@expatriamente.com	(19) 98111-5101	/funcionarios/Carlos Henrique Mathias - Psicanalista Clínico.jpeg.jpg	Psicanalista Clínico	Formação: Engenharia Civil Universidade Gama Filho, Psicanalista Centro de Formação em Psicanálise Clínica, Reiki pelo NeoReiki Institute, ADI-Acesso Direto ao Inconsciente pelo Centro de Formação em Psicanálise Clínica, Hipnoterapia pela OMNI Brasil. Experiência no Exterior: Residência em Angola, África, durante 24 anos, Residência em Portugal por 3 anos, Residência no Peru por 1 ano. Relacionamento empresarial com os seguintes países: Estados Unidos, Rússia, China, Espanha, Inglaterra, Namíbia, Gana, Moçambique e África do Sul.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 5, "startTime": "08:00", "isRecurring": true}, {"id": "slot_5_0930_1", "endTime": "10:30", "isActive": true, "dayOfWeek": 5, "startTime": "09:30", "isRecurring": true}, {"id": "slot_2_1330_0", "endTime": "14:30", "isActive": true, "dayOfWeek": 2, "startTime": "13:30", "isRecurring": true}, {"id": "slot_2_1500_1", "endTime": "16:00", "isActive": true, "dayOfWeek": 2, "startTime": "15:00", "isRecurring": true}, {"id": "slot_2_1700_2", "endTime": "18:00", "isActive": true, "dayOfWeek": 2, "startTime": "17:00", "isRecurring": true}, {"id": "slot_2_1830_3", "endTime": "19:30", "isActive": true, "dayOfWeek": 2, "startTime": "18:30", "isRecurring": true}, {"id": "slot_4_1100_0", "endTime": "12:00", "isActive": true, "dayOfWeek": 4, "startTime": "11:00", "isRecurring": true}, {"id": "slot_4_1330_1", "endTime": "14:30", "isActive": true, "dayOfWeek": 4, "startTime": "13:30", "isRecurring": true}, {"id": "slot_3_1830_0", "endTime": "19:30", "isActive": true, "dayOfWeek": 3, "startTime": "18:30", "isRecurring": true}]}	t	2025-08-26 15:11:34.626	2025-09-05 15:37:09.544	c625c174-5451-4045-96a6-793c8688f56c
1d97c7bb-e720-4c04-a251-bb9343eba546	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Anitta Carelli	anitta.carelli@expatriamente.com	(11) 98263-4538	/funcionarios/Anita Careli - psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Comunicação Social- Publicidade e Propaganda- UNIMEP Piracicaba. Psicanálise- CFPC. Público alvo: Pacientes homens e mulheres a partir de 18 anos.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 5, "startTime": "10:00", "isRecurring": true}, {"id": "slot_5_1100_1", "endTime": "12:00", "isActive": true, "dayOfWeek": 5, "startTime": "11:00", "isRecurring": true}, {"id": "slot_4_1400_0", "endTime": "15:00", "isActive": true, "dayOfWeek": 4, "startTime": "14:00", "isRecurring": true}, {"id": "slot_4_1500_1", "endTime": "16:00", "isActive": true, "dayOfWeek": 4, "startTime": "15:00", "isRecurring": true}, {"id": "slot_3_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 3, "startTime": "10:00", "isRecurring": true}, {"id": "slot_3_1500_1", "endTime": "16:00", "isActive": true, "dayOfWeek": 3, "startTime": "15:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.61	2025-09-05 15:37:09.524	6a90e636-1090-432a-bfb0-1c8ca7352439
241d6e85-1a16-45cd-94c1-fb1e5fdad28b	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Carla Truzzi	carla.truzzi@expatriamente.com	39 346 308-0785	/funcionarios/Ida Carla Truzzi - Psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Psicanalista especializado em atendimento clínico	{"timeOffs": [], "timeSlots": [{"id": "slot_5_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 5, "startTime": "08:00", "isRecurring": true}, {"id": "slot_5_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 5, "startTime": "09:00", "isRecurring": true}, {"id": "slot_5_1000_2", "endTime": "11:00", "isActive": true, "dayOfWeek": 5, "startTime": "10:00", "isRecurring": true}, {"id": "slot_3_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 3, "startTime": "08:00", "isRecurring": true}, {"id": "slot_3_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 3, "startTime": "09:00", "isRecurring": true}, {"id": "slot_3_1000_2", "endTime": "11:00", "isActive": true, "dayOfWeek": 3, "startTime": "10:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.643	2025-09-05 15:37:09.562	6fcba2a8-10a4-4c2c-9ab5-667194348eda
7f6759af-9863-493d-b4d9-3fc7f27ce627	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Juliana Hipólito	juliana.hipolito@expatriamente.com	(19) 99967-7966	/funcionarios/Juliana Hipólito.jpg	Psicanalista Clínico	Formação: Relações públicas - Puc campinas, MBA gestão de pessoas e Mkt pela FGV, Psicanalista - CFPC, Pós Psicanalista infantil - CFPC. Público alvo: indiferente.	{"timeOffs": [], "timeSlots": [{"id": "slot_2_2000_0", "endTime": "21:00", "isActive": true, "dayOfWeek": 2, "startTime": "20:00", "isRecurring": true}, {"id": "slot_3_2000_0", "endTime": "21:00", "isActive": true, "dayOfWeek": 3, "startTime": "20:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.736	2025-09-05 15:37:09.588	9e633398-5111-4098-b54a-583ff575de37
efd2f305-7f3b-47cb-9a54-543993946044	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Juliano Casarin	juliano.casarin@expatriamente.com	(19) 99684-6555	/funcionarios/Juliano Casarin - psicanalista Clínico.jpeg.jpg	Psicanalista Clínico	Psicanalista especializado em atendimento clínico	{"timeOffs": [], "timeSlots": [{"id": "slot_5_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 5, "startTime": "10:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.75	2025-09-05 15:37:09.594	7c7aebbd-ba6d-4d22-83c9-cb47f9ad16c7
40603111-2abe-4847-86fb-46e684fd7c32	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Eduardo Louzas	eduardo.louzas@expatriamente.com	(12) 99787-7773	/funcionarios/Eduardo Louzas - Psicanalista Clínico.jpeg.jpg	Psicanalista Clínico	Formação Acadêmica: Engenharia Civil, Pós-graduação: Engenharia de Segurança, Psicanálise Clínica, ADI (Acesso Direto ao Inconsciente), Constelação Familiar, A cura pela consciência. Pós-graduado em Medicina Psicosomática, GPI (Grupo de Estudos de Psicanálise Integral Keppe &Pacheco) Cursando Teologia Clínica na Faculdade Trilógica Keppe &Pacheco.	{}	t	2025-08-26 15:11:34.674	2025-09-02 15:40:04.808	fb9e3d08-d5bd-4fde-bfa3-a43921c3dab7
fb96675d-7fb5-4ad1-850f-9af414743dc6	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Elza Giorgi (Video)	elza.giorgi.video@expatriamente.com	(19) 98129-0884	/funcionarios/Elza pisicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Não consegue disponibilizar horários neste momento porque está com a agenda comprometida.	{}	t	2025-08-26 15:11:34.69	2025-09-02 15:40:04.821	9d318ec4-b828-457e-8ee9-897bc189ee08
a055bb1b-8880-4799-adf7-4fe462968169	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Carlos Quesada	carlos.quesada@expatriamente.com	(914) 656-9151	/funcionarios/Paulo Quesada de Almeida - Psicanalista CLínico.jpeg.jpg	Psicanalista Clínico	Expatriado vivendo há 5 anos nos Estados Unidos. Formação: Administração PUCCAMP, Psicanálise Clínica CFPC, Especialização em Tratamento Clínico com uso de Métodos de Acesso Direto ao Inconsciente CFPC, Hipnoterapia OMNI, Experiência Somática ASSOCIAÇÃO BRASILEIRA DO TRAUMA, PNL ACTIUS, Inteligência Relacional Sistêmica IDESV, Mestrando em Mental Health Counseling BRESCIA UNIVERSITY. Público-alvo: Homens e Mulheres acima dos 18 anos.	{"timeOffs": [], "timeSlots": [{"id": "slot_4_0830_0", "endTime": "09:30", "isActive": true, "dayOfWeek": 4, "startTime": "08:30", "isRecurring": true}]}	t	2025-08-26 15:11:34.659	2025-09-05 15:37:09.572	cf28272c-4dd9-4b0f-96c9-677447458dce
8d23d3b8-6e20-4578-a503-07e9e2a2dcd6	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Marina Valente	marina.valente@expatriamente.com	(19) 98850-1868	/funcionarios/Mariana Valente - Psicanalista CLínica.jpeg.jpg	Psicanalista Clínico	Formação: Adm - PUCCAMP, Pós grad.: Com. Exterior e Mkt Internacional - Politécnica de Madrid, Pós grad.: Neuropsicologia FAMEESP, Psicanálise - CFPC.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_0900_0", "endTime": "10:00", "isActive": true, "dayOfWeek": 5, "startTime": "09:00", "isRecurring": true}, {"id": "slot_2_1030_0", "endTime": "11:30", "isActive": true, "dayOfWeek": 2, "startTime": "10:30", "isRecurring": true}, {"id": "slot_2_1900_1", "endTime": "20:00", "isActive": true, "dayOfWeek": 2, "startTime": "19:00", "isRecurring": true}, {"id": "slot_4_1900_0", "endTime": "20:00", "isActive": true, "dayOfWeek": 4, "startTime": "19:00", "isRecurring": true}, {"id": "slot_3_1030_0", "endTime": "11:30", "isActive": true, "dayOfWeek": 3, "startTime": "10:30", "isRecurring": true}, {"id": "slot_3_1900_1", "endTime": "20:00", "isActive": true, "dayOfWeek": 3, "startTime": "19:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.779	2025-09-05 15:37:09.625	0a78fd74-623e-41ec-a0c4-967d9d1eac4b
5cf13adf-483a-4967-add4-d830509386fc	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Mary Louzas	mary.louzas@expatriamente.com	(12) 99723-9566	/funcionarios/Mary Louzas.jpg	Psicanalista Clínico	Formação: Decoradora, Recursos Humanos, Practitioner, Física Quântica, Metafísica da Saúde, Constelação Familiar, Eneagrama, Pós Psicanálise, ADI, Terapia de Casal, Consciência Curativa / gerenciamento emocional, Mulheres no Divã, Cursando Teologia Clínica / Faculdade Trilógica.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 5, "startTime": "10:00", "isRecurring": true}, {"id": "slot_4_0900_0", "endTime": "10:00", "isActive": true, "dayOfWeek": 4, "startTime": "09:00", "isRecurring": true}, {"id": "slot_4_1000_1", "endTime": "11:00", "isActive": true, "dayOfWeek": 4, "startTime": "10:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.811	2025-09-05 15:37:09.639	136dd0e8-cca6-484c-ab13-42b23049de39
ebd9a8a0-711e-4052-a73e-9309f8aa4531	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Milton Domingues	milton.domingues@expatriamente.com	(19) 99496-2777	/funcionarios/Milton Domingues - Psicanalista Clínico.jpeg.jpg	Psicanalista Clínico	Graduação: Bacharel em Turismo - PUCCAMP, Especialização em Marketing - PUCCAMP, Psicanálise Clínica - Centro de Formação em Psicanálise Clínica (Turma 40), ADI - Centro de Formação em Psicanálise Clínica, Psicanálise Infantil - Centro de Formação em Psicanálise Clínica, Pós Graduação em Psicanálise Clínica - Centro de Formação em Psicanálise Clínica.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 5, "startTime": "08:00", "isRecurring": true}, {"id": "slot_5_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 5, "startTime": "09:00", "isRecurring": true}, {"id": "slot_5_1900_2", "endTime": "20:00", "isActive": true, "dayOfWeek": 5, "startTime": "19:00", "isRecurring": true}, {"id": "slot_2_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 2, "startTime": "08:00", "isRecurring": true}, {"id": "slot_2_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 2, "startTime": "09:00", "isRecurring": true}, {"id": "slot_2_1900_2", "endTime": "20:00", "isActive": true, "dayOfWeek": 2, "startTime": "19:00", "isRecurring": true}, {"id": "slot_6_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 6, "startTime": "08:00", "isRecurring": true}, {"id": "slot_6_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 6, "startTime": "09:00", "isRecurring": true}, {"id": "slot_6_1900_2", "endTime": "20:00", "isActive": true, "dayOfWeek": 6, "startTime": "19:00", "isRecurring": true}, {"id": "slot_4_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 4, "startTime": "08:00", "isRecurring": true}, {"id": "slot_4_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 4, "startTime": "09:00", "isRecurring": true}, {"id": "slot_4_1900_2", "endTime": "20:00", "isActive": true, "dayOfWeek": 4, "startTime": "19:00", "isRecurring": true}, {"id": "slot_3_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 3, "startTime": "08:00", "isRecurring": true}, {"id": "slot_3_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 3, "startTime": "09:00", "isRecurring": true}, {"id": "slot_3_1900_2", "endTime": "20:00", "isActive": true, "dayOfWeek": 3, "startTime": "19:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.827	2025-09-05 15:37:09.646	181fe581-efa3-4963-923e-35e0b3d7e494
85cb2fba-fc32-4bcc-bc49-0e773c973f2a	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Paula Volpe	paula.volpe@expatriamente.com	(11) 98555-6496	/funcionarios/Paula Volpe - Psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	LETRAS, PÓS GRADUAÇÃO EM MARKETING, PSICANÁLISE CLÍNICA, ADI - Acesso Direto ao Inconsciente, ESPEC. EM PSICANÁLISE PARA CRIANÇAS E ADOLESCENTES, HIPNOTERAPIA ERICKSONIANA, PSICOLOGIA ANALÍTICA (JUNGUIANA), PSICOSSOMÁTICA (em formação), EDUCAÇÃO CONT. - SUJEITOS DA PSICANÁLISE (em formação) UNIVERSIDADE MACKENZIE, FAAP, CENTRO DE FORMAÇÃO EM PSICANÁLISE CLÍNICA, CEFAS - ESCOLA DE PSICANÁLISE, INSTITUTO SOFIA BAUER, IJEP- INSTITUTO JUNGUIANO DE ENSINO E PESQUISA, INSTITUTO FREEDOM, PUC - SÃO PAULO.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_0700_0", "endTime": "08:00", "isActive": true, "dayOfWeek": 5, "startTime": "07:00", "isRecurring": true}, {"id": "slot_5_0800_1", "endTime": "09:00", "isActive": true, "dayOfWeek": 5, "startTime": "08:00", "isRecurring": true}, {"id": "slot_5_1100_2", "endTime": "12:00", "isActive": true, "dayOfWeek": 5, "startTime": "11:00", "isRecurring": true}, {"id": "slot_5_1300_3", "endTime": "14:00", "isActive": true, "dayOfWeek": 5, "startTime": "13:00", "isRecurring": true}, {"id": "slot_2_0700_0", "endTime": "08:00", "isActive": true, "dayOfWeek": 2, "startTime": "07:00", "isRecurring": true}, {"id": "slot_2_0800_1", "endTime": "09:00", "isActive": true, "dayOfWeek": 2, "startTime": "08:00", "isRecurring": true}, {"id": "slot_2_1100_2", "endTime": "12:00", "isActive": true, "dayOfWeek": 2, "startTime": "11:00", "isRecurring": true}, {"id": "slot_2_1400_3", "endTime": "15:00", "isActive": true, "dayOfWeek": 2, "startTime": "14:00", "isRecurring": true}, {"id": "slot_2_1600_4", "endTime": "17:00", "isActive": true, "dayOfWeek": 2, "startTime": "16:00", "isRecurring": true}, {"id": "slot_4_0700_0", "endTime": "08:00", "isActive": true, "dayOfWeek": 4, "startTime": "07:00", "isRecurring": true}, {"id": "slot_4_1100_1", "endTime": "12:00", "isActive": true, "dayOfWeek": 4, "startTime": "11:00", "isRecurring": true}, {"id": "slot_4_1200_2", "endTime": "13:00", "isActive": true, "dayOfWeek": 4, "startTime": "12:00", "isRecurring": true}, {"id": "slot_4_1400_3", "endTime": "15:00", "isActive": true, "dayOfWeek": 4, "startTime": "14:00", "isRecurring": true}, {"id": "slot_4_1500_4", "endTime": "16:00", "isActive": true, "dayOfWeek": 4, "startTime": "15:00", "isRecurring": true}, {"id": "slot_3_0700_0", "endTime": "08:00", "isActive": true, "dayOfWeek": 3, "startTime": "07:00", "isRecurring": true}, {"id": "slot_3_1100_1", "endTime": "12:00", "isActive": true, "dayOfWeek": 3, "startTime": "11:00", "isRecurring": true}, {"id": "slot_3_1200_2", "endTime": "13:00", "isActive": true, "dayOfWeek": 3, "startTime": "12:00", "isRecurring": true}, {"id": "slot_3_1500_3", "endTime": "16:00", "isActive": true, "dayOfWeek": 3, "startTime": "15:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.841	2025-09-05 15:37:09.655	a5f4839c-22ea-4beb-aa77-01f083e23830
0a05bfe7-fc10-44fe-85bd-bc0544944c0a	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Pedro Arruda	pedro.arruda@expatriamente.com	(21) 99692-5439	/funcionarios/Pedro Aramis Arruda - Psicanalista Clínico.jpeg.jpg	Psicanalista Clínico	Decidi dedicar-me à Psicanálise, concluindo o curso no Centro de Formação em Psicanálise Clínica (CFPC) na turma XLIII, 2024. No CFPC, também conclui os cursos de Terapia de Casais, Acesso Direto ao Inconsciente e Psicanálise Infantil. Formei-me em Educação Física 1975, cursei Estado-Maior em 1987/88 e especializei-me em Análise de Situações de Crise em 1999. Servi em vários estados no Brasil e cumpri duas missões no exterior, acompanhado da família. Cursei a Escola de Guerra do Exército dos Estados Unidos (USAWC) em 1992/93 e fui Adido de Defesa em Angola (1999/2000). Após deixar o serviço, Gerente de Segurança Empresarial da PETROBRAS, responsável pela proteção de pessoas, instalações e informações das empresas do Sistema, entre 2005 e 2015, oportunidade em que pude apoiar empregados em situações de crises no exterior, como na Nigéria (2009/10) e na Líbia (2011).	{"timeOffs": [], "timeSlots": [{"id": "slot_4_1600_0", "endTime": "17:00", "isActive": true, "dayOfWeek": 4, "startTime": "16:00", "isRecurring": true}, {"id": "slot_3_1700_0", "endTime": "18:00", "isActive": true, "dayOfWeek": 3, "startTime": "17:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.866	2025-09-05 15:37:09.662	4401a10e-7370-4f84-b770-0f6884077d73
2c4b2f18-8788-42aa-a91d-5d3495b86d87	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Sylvia Maluf	sylvia.maluf@expatriamente.com	(11) 98555-1212	/funcionarios/Sylvia Duarte Maluf - Psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Cobra R$ 200,00 atualmente. Formação: Direito - USF, Psicanálise - CFPC, Psicologia Analítica - IJEP - SP. Público Alvo: 15 e 70 anos - homem ou mulher.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_0900_0", "endTime": "10:00", "isActive": true, "dayOfWeek": 5, "startTime": "09:00", "isRecurring": true}, {"id": "slot_5_1000_1", "endTime": "11:00", "isActive": true, "dayOfWeek": 5, "startTime": "10:00", "isRecurring": true}, {"id": "slot_2_0900_0", "endTime": "10:00", "isActive": true, "dayOfWeek": 2, "startTime": "09:00", "isRecurring": true}, {"id": "slot_4_0900_0", "endTime": "10:00", "isActive": true, "dayOfWeek": 4, "startTime": "09:00", "isRecurring": true}, {"id": "slot_4_1000_1", "endTime": "11:00", "isActive": true, "dayOfWeek": 4, "startTime": "10:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.88	2025-09-05 15:37:09.668	0a7d1d69-06cc-4648-8480-e399f843d523
307f6e5c-b314-4a3c-92e6-84364dc8eab0	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Vilma Zotareli	vilma.zotareli@expatriamente.com	(19) 98122-3408	/funcionarios/Vilma Zotareli - Psicanalista Clínico.jpeg.jpg	Psicanalista Clínico	Formação: Letras, PUCCAMP. Especialização, Mestrado e Doutorado, UNICAMP. Especialização Clínica, CFPC. Especialização em Tratamento Clínico com uso de Métodos de Acesso Direto ao Inconsciente (ADI), CFPC. Público-alvo: Homens e Mulheres entre 18 a 80 anos.	{"timeOffs": [], "timeSlots": [{"id": "slot_4_1600_0", "endTime": "17:00", "isActive": true, "dayOfWeek": 4, "startTime": "16:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.908	2025-09-05 15:37:09.679	7a7c0ac0-1b54-45d6-a9af-047492bf80ef
f0c243dc-cb38-448a-a8d1-4237884cc67f	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Waldomiro N. Santos	waldomiro.n.santos@expatriamente.com	(19) 99998-9587	/funcionarios/Waldomiro Santos.jpg	Psicanalista Clínico	Formação: Engenharia Elétrica – UNICAMP, Física – UNICAMP, Psicanálise – CFPC, Pós-graduação em Psicanálise – FAATESP, ADI (Acesso Direto ao Inconsciente) - CFPC, Hipnose Ericksoniana – ACT Institute, Focalização - INSTITUTO DE FOCALIZAÇÃO E ALQUIMIA INTERIOR, Psicotraumatologia - INSTITUTO DE FOCALIZAÇÃO E ALQUIMIA INTERIOR. Público alvo: pacientes maiores de 18 anos.	{"timeOffs": [], "timeSlots": [{"id": "slot_2_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 2, "startTime": "10:00", "isRecurring": true}, {"id": "slot_3_1000_0", "endTime": "11:00", "isActive": true, "dayOfWeek": 3, "startTime": "10:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.92	2025-09-05 15:37:09.685	9639f73a-b536-434a-8f7d-53257703e506
7c364568-2cfc-4b11-a925-3e048ee2282c	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	José Carlos Pires Júnior	jose.carlos.pires.junior@expatriamente.com	(11) 976026002	/funcionarios/Jose Carlos Pires Junior.jpg	Psicanalista Clínico	Formação: Ciências da Computação – PUC–SP, Marketing de Serviços e Gestão em Tecnologia – FGV–SP, Psicanálise – CFPC, Campinas. Experiência: 25+ anos de experiência em multinacionais, ampla vivência internacional e multicultural (Europa, Ásia e Américas), liderança de times globais. Experiência como expatriado (País: Alemanha). Público-alvo: Adolescentes (a partir de 12 anos) e adultos. Atendimento em português, inglês e espanhol.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_1800_0", "endTime": "19:00", "isActive": true, "dayOfWeek": 5, "startTime": "18:00", "isRecurring": true}, {"id": "slot_5_1900_1", "endTime": "20:00", "isActive": true, "dayOfWeek": 5, "startTime": "19:00", "isRecurring": true}, {"id": "slot_5_2000_2", "endTime": "21:00", "isActive": true, "dayOfWeek": 5, "startTime": "20:00", "isRecurring": true}, {"id": "slot_4_1700_0", "endTime": "18:00", "isActive": true, "dayOfWeek": 4, "startTime": "17:00", "isRecurring": true}, {"id": "slot_4_1800_1", "endTime": "19:00", "isActive": true, "dayOfWeek": 4, "startTime": "18:00", "isRecurring": true}, {"id": "slot_4_1900_2", "endTime": "20:00", "isActive": true, "dayOfWeek": 4, "startTime": "19:00", "isRecurring": true}, {"id": "slot_4_2100_3", "endTime": "22:00", "isActive": true, "dayOfWeek": 4, "startTime": "21:00", "isRecurring": true}, {"id": "slot_3_0630_0", "endTime": "07:30", "isActive": true, "dayOfWeek": 3, "startTime": "06:30", "isRecurring": true}]}	t	2025-08-26 15:11:34.721	2025-09-05 15:37:09.581	1fc3fdfa-f67c-412d-a799-be05e7cfbc5c
48d062be-5d0a-4211-849e-15dbb8b3b296	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Paula Carelli de Noronha Peres	paula.carelli.de.noronha.peres@expatriamente.com	(19) 99602-6867	/funcionarios/Paula Carelli de Noronha Peres - Psicanalista Clínica.jpeg.jpg	Psicanalista Clínico	Formada em Medicina pela Puccamp em 1994; residência médica em cirurgia geral (1996 a 1998); residência médica em cirurgia plástica (1999 a 2001). Formada em Psicanálise pela Escola de Psicanálise Clínica em 2005; curso de ADI (acesso direto ao inconsciente). Disponível para atendimentos: sextas-feiras: 16 horas; 17 horas; 18 horas e 19 horas; quartas- feiras: 15 horas; quintas-feiras: 18 horas.	{"timeOffs": [], "timeSlots": [{"id": "slot_5_1800_0", "endTime": "19:00", "isActive": true, "dayOfWeek": 5, "startTime": "18:00", "isRecurring": true}, {"id": "slot_6_1600_0", "endTime": "17:00", "isActive": true, "dayOfWeek": 6, "startTime": "16:00", "isRecurring": true}, {"id": "slot_6_1700_1", "endTime": "18:00", "isActive": true, "dayOfWeek": 6, "startTime": "17:00", "isRecurring": true}, {"id": "slot_6_1800_2", "endTime": "19:00", "isActive": true, "dayOfWeek": 6, "startTime": "18:00", "isRecurring": true}, {"id": "slot_4_1500_0", "endTime": "16:00", "isActive": true, "dayOfWeek": 4, "startTime": "15:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.853	2025-09-05 15:37:09.601	dbf20ba6-cd05-494f-9960-d0747ae8e799
624659b3-9523-47ff-ae65-f82d4f292464	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Masayuki	masayuki@expatriamente.com	(11) 99386-1655	/funcionarios/Masayuki Kawakami - Psicanalista Clínico.jpeg.jpg	Psicanalista Clínico	Engenharia - Poli USP, Pós Elementos Finitos - ITA, Pós administração - FEAUSP, Psicanálise - CFPC. Público Alvo: adulto entre 20 e 100 anos.	{"timeOffs": [], "timeSlots": [{"id": "slot_6_0800_0", "endTime": "09:00", "isActive": true, "dayOfWeek": 6, "startTime": "08:00", "isRecurring": true}, {"id": "slot_6_0900_1", "endTime": "10:00", "isActive": true, "dayOfWeek": 6, "startTime": "09:00", "isRecurring": true}, {"id": "slot_6_1000_2", "endTime": "11:00", "isActive": true, "dayOfWeek": 6, "startTime": "10:00", "isRecurring": true}, {"id": "slot_6_1100_3", "endTime": "12:00", "isActive": true, "dayOfWeek": 6, "startTime": "11:00", "isRecurring": true}, {"id": "slot_6_1500_4", "endTime": "16:00", "isActive": true, "dayOfWeek": 6, "startTime": "15:00", "isRecurring": true}, {"id": "slot_6_1600_5", "endTime": "17:00", "isActive": true, "dayOfWeek": 6, "startTime": "16:00", "isRecurring": true}, {"id": "slot_6_1700_6", "endTime": "18:00", "isActive": true, "dayOfWeek": 6, "startTime": "17:00", "isRecurring": true}, {"id": "slot_6_1800_7", "endTime": "19:00", "isActive": true, "dayOfWeek": 6, "startTime": "18:00", "isRecurring": true}, {"id": "slot_6_1900_8", "endTime": "20:00", "isActive": true, "dayOfWeek": 6, "startTime": "19:00", "isRecurring": true}, {"id": "slot_6_2100_9", "endTime": "22:00", "isActive": true, "dayOfWeek": 6, "startTime": "21:00", "isRecurring": true}]}	t	2025-08-26 15:11:34.794	2025-09-05 15:37:09.632	9b5411c4-fa13-4cfe-931f-4be19d602a23
\.


--
-- Data for Name: financial_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financial_goals (id, client_id, workspace_id, user_id, title, description, target_amount, current_amount, category, target_date, status, priority, is_public, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: frontend_cache_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.frontend_cache_metadata (id, client_id, cache_key, last_updated, version, data_size, hit_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, product_id, quantity, price, subtotal, "totalPrice") FROM stdin;
c6562c03-0e11-4a90-bb4d-270a08527dea	686d1068-d0c0-460f-b886-42d71e526aa3	690b84ad-d919-48cf-9d3b-8efd002bd8df	1	58.90	58.90	58.90
95919e87-36b8-4dfa-94d7-2d1a3a68b9a3	686d1068-d0c0-460f-b886-42d71e526aa3	1a493301-2eda-4d3c-940a-df5e740a0ae4	1	45.90	45.90	45.90
5a5463d2-3965-4d29-bf6b-6c41f8101cca	686d1068-d0c0-460f-b886-42d71e526aa3	46deb9d9-fa49-4ded-aa59-5162256b0a6a	1	28.90	28.90	28.90
ef9a5daa-c999-433d-898d-7823bcf5a7d1	686d1068-d0c0-460f-b886-42d71e526aa3	6d9c089c-87cd-4aa7-96a1-d8d312185918	1	35.90	35.90	35.90
a5a785e7-922a-4e67-905b-14a7a77f59a2	73bd27a1-d139-4831-bd82-db0906e614dd	c2e680c8-58b3-40ec-a014-851b282cb295	3	78.90	236.70	236.70
edf9c97e-e83b-478c-9501-58f2825fc11e	73bd27a1-d139-4831-bd82-db0906e614dd	8e02ee47-2c0e-4853-bfaf-15c015445511	1	89.90	89.90	89.90
1cf5ece4-87e0-4ad0-8c43-1ba80daa9b1e	73bd27a1-d139-4831-bd82-db0906e614dd	ff371e7c-50c5-4003-aa16-0be2ce9e0171	3	42.90	128.70	128.70
1fb241da-8ad3-41d5-a3b9-b721bdfd5cc0	73bd27a1-d139-4831-bd82-db0906e614dd	cdf7d7fd-2ce8-4679-8d16-08f1285e48fa	3	32.50	97.50	97.50
1eb9a427-5d93-44ee-849c-748448401b51	334951b0-cc94-482d-88d2-c29d3e5cfa70	2cd36091-7758-4eeb-ab2c-e2095ad5f96c	2	42.90	85.80	85.80
4461c45c-16ff-4908-b446-85783819874e	334951b0-cc94-482d-88d2-c29d3e5cfa70	46deb9d9-fa49-4ded-aa59-5162256b0a6a	3	28.90	86.70	86.70
cb87ac08-6d88-49c3-911c-60fb365d3865	334951b0-cc94-482d-88d2-c29d3e5cfa70	8e02ee47-2c0e-4853-bfaf-15c015445511	1	89.90	89.90	89.90
f050b286-cfc8-49e1-9e79-30e2363c379d	334951b0-cc94-482d-88d2-c29d3e5cfa70	e0e234c0-2dc1-4b42-8bec-54d7f46e7c4b	3	39.90	119.70	119.70
6eab94a9-1f21-4f9b-bbb7-a8a7a5d3848b	38af6b6d-186d-4027-8224-b7c284279b04	8e02ee47-2c0e-4853-bfaf-15c015445511	3	89.90	269.70	269.70
fbb4bbd6-3669-4bb0-b438-dfe24642f011	38af6b6d-186d-4027-8224-b7c284279b04	2cd36091-7758-4eeb-ab2c-e2095ad5f96c	1	42.90	42.90	42.90
a058539a-7d33-4963-952b-cc161bd4fbb8	1f8f88a9-1af3-44f8-aa4d-dc8fd2bdf140	6d9c089c-87cd-4aa7-96a1-d8d312185918	2	35.90	71.80	71.80
89e05221-45ff-42ee-b1dd-469a780e806e	1f8f88a9-1af3-44f8-aa4d-dc8fd2bdf140	5d3bc880-ef86-419e-ba10-d2fb6a8dce82	2	89.90	179.80	179.80
4574c693-e27d-4032-b0c5-c31cc4cd5497	1f8f88a9-1af3-44f8-aa4d-dc8fd2bdf140	cd5fcea4-ab53-4a98-8ab0-2c5a0a5b60ea	3	65.90	197.70	197.70
941e67bd-aea3-4721-ad3d-f6c46f0310fe	1f8f88a9-1af3-44f8-aa4d-dc8fd2bdf140	7831ce34-e038-4d6b-bc4a-131a31f67c64	1	58.90	58.90	58.90
59ebb8e8-4ec2-4392-b2b9-1c59e1f25ae1	b0164201-2b5a-467d-b7c6-aea02afb3685	6d9c089c-87cd-4aa7-96a1-d8d312185918	3	35.90	107.70	107.70
397b14b0-9440-477d-a25a-7ab78a0e0e19	b0164201-2b5a-467d-b7c6-aea02afb3685	690b84ad-d919-48cf-9d3b-8efd002bd8df	3	58.90	176.70	176.70
cf24c59f-c903-443e-8afa-33d1ffffd179	b0164201-2b5a-467d-b7c6-aea02afb3685	4e46f5eb-3366-4bfc-a7c9-fa3cbbae83ce	1	45.90	45.90	45.90
4c132ad3-e00b-47e8-ac96-7d6815f8808e	b0164201-2b5a-467d-b7c6-aea02afb3685	cd5fcea4-ab53-4a98-8ab0-2c5a0a5b60ea	3	65.90	197.70	197.70
068e23c2-c02e-4f4e-9879-939677a15a25	4910c01c-0cb5-4b93-88a4-66b4cb19af11	690b84ad-d919-48cf-9d3b-8efd002bd8df	3	58.90	176.70	176.70
b0278e63-cfb9-4270-bf10-7f1b3635cc0e	4910c01c-0cb5-4b93-88a4-66b4cb19af11	8e02ee47-2c0e-4853-bfaf-15c015445511	1	89.90	89.90	89.90
b40f4068-2ab1-40dc-bd45-7d438f95faf1	4910c01c-0cb5-4b93-88a4-66b4cb19af11	690b84ad-d919-48cf-9d3b-8efd002bd8df	3	58.90	176.70	176.70
b33d2591-5e80-4155-931a-e7e4cb771226	4910c01c-0cb5-4b93-88a4-66b4cb19af11	46deb9d9-fa49-4ded-aa59-5162256b0a6a	3	28.90	86.70	86.70
a07df65a-b4de-4932-8395-44afd1f1812b	2c03f7c6-bc48-4d17-82a2-56cb31d9737e	a0d0e8f4-664e-440c-9e8c-c95cbc4fd2ad	2	48.90	97.80	97.80
a4d22dab-b761-4836-890a-f34496b46bc2	2c03f7c6-bc48-4d17-82a2-56cb31d9737e	5d3bc880-ef86-419e-ba10-d2fb6a8dce82	2	89.90	179.80	179.80
0bb413e7-c382-4dc2-8980-ecbe172b73ae	2c03f7c6-bc48-4d17-82a2-56cb31d9737e	ff371e7c-50c5-4003-aa16-0be2ce9e0171	1	42.90	42.90	42.90
614497a3-7ea2-472e-8849-4face18f70d0	6500ebea-47d5-4c2c-82cc-83822e357fb8	4e46f5eb-3366-4bfc-a7c9-fa3cbbae83ce	1	45.90	45.90	45.90
6e4f5452-e408-4b30-83df-3a1f51ff28a4	6500ebea-47d5-4c2c-82cc-83822e357fb8	3106d727-0e11-43a9-91a9-60f0c2d754fd	2	67.80	135.60	135.60
4afb1e4e-8bb8-424d-ac7c-f946d24cc6e9	6500ebea-47d5-4c2c-82cc-83822e357fb8	3106d727-0e11-43a9-91a9-60f0c2d754fd	2	67.80	135.60	135.60
07822f03-3520-4658-aa05-3c780547d57c	6500ebea-47d5-4c2c-82cc-83822e357fb8	690b84ad-d919-48cf-9d3b-8efd002bd8df	1	58.90	58.90	58.90
6d448f21-fa44-451d-a485-3458e6a5e0e3	6500ebea-47d5-4c2c-82cc-83822e357fb8	46deb9d9-fa49-4ded-aa59-5162256b0a6a	2	28.90	57.80	57.80
c92c493b-07bb-4bba-856b-82b75ffd3779	ca2510c0-015d-4cff-8824-bd59ee58fa23	6d9c089c-87cd-4aa7-96a1-d8d312185918	2	35.90	71.80	71.80
4d52e828-c2f1-4123-a9fd-e8c3efb3f074	ca2510c0-015d-4cff-8824-bd59ee58fa23	c2e680c8-58b3-40ec-a014-851b282cb295	1	78.90	78.90	78.90
d2101adf-ebe2-4331-a0c2-473423e88058	ca2510c0-015d-4cff-8824-bd59ee58fa23	a0d0e8f4-664e-440c-9e8c-c95cbc4fd2ad	3	48.90	146.70	146.70
e0090a17-7ac6-48b7-a276-15cf28b38fa2	ca2510c0-015d-4cff-8824-bd59ee58fa23	1a493301-2eda-4d3c-940a-df5e740a0ae4	1	45.90	45.90	45.90
e15d76fc-c768-4c23-891f-3335b073b5c0	ca2510c0-015d-4cff-8824-bd59ee58fa23	4e46f5eb-3366-4bfc-a7c9-fa3cbbae83ce	3	45.90	137.70	137.70
4e1b3508-45f3-4aad-81bd-4d504db98fbb	fd089d9b-3eeb-4cd0-b560-fd70d8400032	5d3bc880-ef86-419e-ba10-d2fb6a8dce82	3	89.90	269.70	269.70
48adda47-86f1-45a3-b716-6b86cd7d36ac	fd089d9b-3eeb-4cd0-b560-fd70d8400032	7831ce34-e038-4d6b-bc4a-131a31f67c64	2	58.90	117.80	117.80
e4916ede-3e83-4601-9975-6395646812de	fd089d9b-3eeb-4cd0-b560-fd70d8400032	8c27fc42-8544-438c-9b41-5eed38a46a5d	2	54.90	109.80	109.80
9f899143-90c1-4876-b5da-7047ab4ff990	fd089d9b-3eeb-4cd0-b560-fd70d8400032	7831ce34-e038-4d6b-bc4a-131a31f67c64	1	58.90	58.90	58.90
18847545-a3c8-4b39-85a6-3a1a949f0828	fd089d9b-3eeb-4cd0-b560-fd70d8400032	8c27fc42-8544-438c-9b41-5eed38a46a5d	2	54.90	109.80	109.80
18160d25-9057-4e45-b5b2-c5c7c38f4ea8	bf87a15f-d1cf-40da-b9b8-36e84ffcea23	287837fd-81d2-4a2a-bc58-96c41e6d18b0	2	78.90	157.80	157.80
364a629c-0c21-4aa4-acb2-e0e848dc9848	3b13b435-c954-43fa-843d-ff2b7a4c7819	c2e680c8-58b3-40ec-a014-851b282cb295	1	78.90	78.90	78.90
baa63232-0342-4b00-acfa-6b5f8d0bb2ce	3b13b435-c954-43fa-843d-ff2b7a4c7819	3106d727-0e11-43a9-91a9-60f0c2d754fd	3	67.80	203.40	203.40
aabd6b00-2559-42bd-a9fa-b13b9c74c8f1	3b13b435-c954-43fa-843d-ff2b7a4c7819	7831ce34-e038-4d6b-bc4a-131a31f67c64	2	58.90	117.80	117.80
5fd16d15-090e-4ea0-a9ff-e385943c1e9d	3b13b435-c954-43fa-843d-ff2b7a4c7819	e0e234c0-2dc1-4b42-8bec-54d7f46e7c4b	3	39.90	119.70	119.70
e7187338-14c1-4920-8ebb-64792357894b	2893468f-6f6b-4f03-9abc-c9189d060a06	a0d0e8f4-664e-440c-9e8c-c95cbc4fd2ad	3	48.90	146.70	146.70
a85154fb-abd0-4613-aaf2-1898fc49c370	2893468f-6f6b-4f03-9abc-c9189d060a06	6d9c089c-87cd-4aa7-96a1-d8d312185918	1	35.90	35.90	35.90
e6faa001-7522-4a08-9630-fe903d4a2e31	2893468f-6f6b-4f03-9abc-c9189d060a06	cd5fcea4-ab53-4a98-8ab0-2c5a0a5b60ea	1	65.90	65.90	65.90
9c9373e6-aeab-46ac-8d51-b2ebeed460a8	9d56d5c1-be3c-4669-8cf9-cb9153715d3a	d8283add-ca5c-48e1-8e3c-b188e50ed453	2	35.90	71.80	71.80
fa691067-6e7a-4713-9829-2ac37e1d29f2	e305657f-e28b-4caa-ba36-276cd8647dea	46deb9d9-fa49-4ded-aa59-5162256b0a6a	1	28.90	28.90	28.90
ee1cfe3e-293d-48f7-8cca-f598956a1537	e305657f-e28b-4caa-ba36-276cd8647dea	8c27fc42-8544-438c-9b41-5eed38a46a5d	3	54.90	164.70	164.70
65150250-55d7-4962-9b4e-074adc287832	e305657f-e28b-4caa-ba36-276cd8647dea	287837fd-81d2-4a2a-bc58-96c41e6d18b0	2	78.90	157.80	157.80
10194222-7b6d-40db-bbc7-687aa9dfa1f7	fbfdd61f-d8b9-4d9b-b860-988e1cdc6511	46deb9d9-fa49-4ded-aa59-5162256b0a6a	2	28.90	57.80	57.80
ce18a317-f160-46de-bbdd-a1edc2be5d66	fbfdd61f-d8b9-4d9b-b860-988e1cdc6511	1a493301-2eda-4d3c-940a-df5e740a0ae4	1	45.90	45.90	45.90
1db6686a-4c8b-4c84-9126-2b50dd24ea04	1b798158-0f03-4df1-a6f5-f56130fb90e3	4e46f5eb-3366-4bfc-a7c9-fa3cbbae83ce	2	45.90	91.80	91.80
cc8e391a-6db6-4750-99ac-6139e0bf90d9	1b798158-0f03-4df1-a6f5-f56130fb90e3	c2e680c8-58b3-40ec-a014-851b282cb295	3	78.90	236.70	236.70
e736426d-6f22-41ea-8949-e2b860645889	3c194971-715e-4fe6-bd13-b9b60d4fc79b	c2e680c8-58b3-40ec-a014-851b282cb295	3	78.90	236.70	236.70
7689af9d-66dd-47e3-b954-68f103c3e01f	3c194971-715e-4fe6-bd13-b9b60d4fc79b	1a493301-2eda-4d3c-940a-df5e740a0ae4	3	45.90	137.70	137.70
15b876ba-89f4-4573-9df6-dc0c5d25b61a	3c194971-715e-4fe6-bd13-b9b60d4fc79b	46deb9d9-fa49-4ded-aa59-5162256b0a6a	2	28.90	57.80	57.80
05543ef9-1629-450e-af4e-054e55fde3fd	3c194971-715e-4fe6-bd13-b9b60d4fc79b	287837fd-81d2-4a2a-bc58-96c41e6d18b0	3	78.90	236.70	236.70
12b1152b-5f5c-40a1-94b4-a2f4ce316009	3c194971-715e-4fe6-bd13-b9b60d4fc79b	46deb9d9-fa49-4ded-aa59-5162256b0a6a	3	28.90	86.70	86.70
9d55baa8-866d-4818-8796-826621faadb4	67d28703-dbfa-476d-ab64-d84a6126df6f	8e02ee47-2c0e-4853-bfaf-15c015445511	1	89.90	89.90	89.90
6661b193-9a1e-465a-929b-11a1b6dab718	67d28703-dbfa-476d-ab64-d84a6126df6f	4e46f5eb-3366-4bfc-a7c9-fa3cbbae83ce	1	45.90	45.90	45.90
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, client_id, user_id, "orderNumber", status, total, "deliveryAddress", "deliveryFee", "paymentStatus", "paymentMethod", "createdAt", "updatedAt") FROM stdin;
686d1068-d0c0-460f-b886-42d71e526aa3	4a2d7176-3f9d-43da-9a7f-e97d08f54744	6396a192-2f09-49f8-9739-368e143c323b	BM-1759875116009-0	PREPARING	169.60	Rua 953, 38	15.00	FAILED	PIX	2025-08-02 21:53:14.786	2025-10-07 22:11:56.01
73bd27a1-d139-4831-bd82-db0906e614dd	4a2d7176-3f9d-43da-9a7f-e97d08f54744	6396a192-2f09-49f8-9739-368e143c323b	BM-1759875116061-1	CANCELLED	552.80	Rua 988, 65	13.00	PENDING	CREDIT_CARD	2025-08-25 13:53:27.698	2025-10-07 22:11:56.062
334951b0-cc94-482d-88d2-c29d3e5cfa70	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ed7d6ffb-8273-4316-8394-9ae757076482	BM-1759875116096-2	PREPARING	382.10	Rua 555, 25	16.00	PENDING	CREDIT_CARD	2025-09-10 04:19:27.033	2025-10-07 22:11:56.097
38af6b6d-186d-4027-8224-b7c284279b04	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ceeaca49-e901-41d5-8c81-cc6cc09fd12e	BM-1759875116134-3	DELIVERED	312.60	Rua 351, 88	16.00	REFUNDED	CREDIT_CARD	2025-10-04 09:48:43.015	2025-10-07 22:11:56.135
1f8f88a9-1af3-44f8-aa4d-dc8fd2bdf140	4a2d7176-3f9d-43da-9a7f-e97d08f54744	7facff7a-e12e-4c1a-8661-0d171175f8f2	BM-1759875116154-4	CANCELLED	508.20	Rua 273, 30	15.00	PENDING	BOLETO	2025-09-24 10:31:16.429	2025-10-07 22:11:56.155
b0164201-2b5a-467d-b7c6-aea02afb3685	4a2d7176-3f9d-43da-9a7f-e97d08f54744	52f97c9f-e174-48f3-906c-4c13add2f47e	BM-1759875116184-5	PREPARING	528.00	Rua 931, 97	23.00	PAID	BOLETO	2025-09-23 15:56:24.194	2025-10-07 22:11:56.186
4910c01c-0cb5-4b93-88a4-66b4cb19af11	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ed7d6ffb-8273-4316-8394-9ae757076482	BM-1759875116212-6	PENDING	530.00	Rua 817, 90	22.00	FAILED	BOLETO	2025-10-05 21:39:52.93	2025-10-07 22:11:56.213
2c03f7c6-bc48-4d17-82a2-56cb31d9737e	4a2d7176-3f9d-43da-9a7f-e97d08f54744	92e3da2a-e84c-4093-b651-5f8b0d18ce40	BM-1759875116243-7	READY	320.50	Rua 684, 95	13.00	REFUNDED	BOLETO	2025-09-24 02:52:55.516	2025-10-07 22:11:56.244
6500ebea-47d5-4c2c-82cc-83822e357fb8	4a2d7176-3f9d-43da-9a7f-e97d08f54744	488444ca-9356-4c3e-819e-a8ad0031005c	BM-1759875116264-8	READY	433.80	Rua 286, 13	13.00	REFUNDED	CREDIT_CARD	2025-07-31 06:03:07.88	2025-10-07 22:11:56.265
ca2510c0-015d-4cff-8824-bd59ee58fa23	4a2d7176-3f9d-43da-9a7f-e97d08f54744	354a6f84-c351-4329-91a9-15a4dd295951	BM-1759875116304-9	PREPARING	481.00	Rua 907, 37	13.00	REFUNDED	CREDIT_CARD	2025-09-21 03:30:36.892	2025-10-07 22:11:56.305
fd089d9b-3eeb-4cd0-b560-fd70d8400032	4a2d7176-3f9d-43da-9a7f-e97d08f54744	8925fab5-304c-4ee8-a791-5590dc43f806	BM-1759875116334-10	OUT_FOR_DELIVERY	666.00	Rua 254, 12	12.00	REFUNDED	BOLETO	2025-09-23 17:35:27.601	2025-10-07 22:11:56.335
bf87a15f-d1cf-40da-b9b8-36e84ffcea23	4a2d7176-3f9d-43da-9a7f-e97d08f54744	8925fab5-304c-4ee8-a791-5590dc43f806	BM-1759875116360-11	READY	157.80	Rua 305, 86	15.00	PENDING	BOLETO	2025-07-12 06:42:08.887	2025-10-07 22:11:56.361
3b13b435-c954-43fa-843d-ff2b7a4c7819	4a2d7176-3f9d-43da-9a7f-e97d08f54744	92e3da2a-e84c-4093-b651-5f8b0d18ce40	BM-1759875116370-12	OUT_FOR_DELIVERY	519.80	Rua 706, 94	22.00	PAID	PIX	2025-07-18 04:48:10.267	2025-10-07 22:11:56.371
2893468f-6f6b-4f03-9abc-c9189d060a06	4a2d7176-3f9d-43da-9a7f-e97d08f54744	1ac729a4-f041-4aab-ac1d-d0958372dddc	BM-1759875116392-13	DELIVERED	248.50	Rua 932, 28	14.00	REFUNDED	BOLETO	2025-09-18 08:56:20.164	2025-10-07 22:11:56.393
9d56d5c1-be3c-4669-8cf9-cb9153715d3a	4a2d7176-3f9d-43da-9a7f-e97d08f54744	354a6f84-c351-4329-91a9-15a4dd295951	BM-1759875116410-14	CONFIRMED	71.80	Rua 20, 87	20.00	FAILED	BOLETO	2025-09-25 17:14:52.287	2025-10-07 22:11:56.411
e305657f-e28b-4caa-ba36-276cd8647dea	4a2d7176-3f9d-43da-9a7f-e97d08f54744	354a6f84-c351-4329-91a9-15a4dd295951	BM-1759875116418-15	CONFIRMED	351.40	Rua 274, 94	19.00	FAILED	PIX	2025-09-24 22:26:35.083	2025-10-07 22:11:56.419
fbfdd61f-d8b9-4d9b-b860-988e1cdc6511	4a2d7176-3f9d-43da-9a7f-e97d08f54744	3138a981-e63c-47ea-95b3-834a797af950	BM-1759875116434-16	PENDING	103.70	Rua 595, 80	10.00	FAILED	CREDIT_CARD	2025-08-06 23:43:57.831	2025-10-07 22:11:56.435
1b798158-0f03-4df1-a6f5-f56130fb90e3	4a2d7176-3f9d-43da-9a7f-e97d08f54744	52f97c9f-e174-48f3-906c-4c13add2f47e	BM-1759875116446-17	READY	328.50	Rua 502, 87	8.00	PENDING	PIX	2025-09-19 17:35:19.32	2025-10-07 22:11:56.447
3c194971-715e-4fe6-bd13-b9b60d4fc79b	4a2d7176-3f9d-43da-9a7f-e97d08f54744	7facff7a-e12e-4c1a-8661-0d171175f8f2	BM-1759875116458-18	READY	755.60	Rua 230, 64	9.00	FAILED	BOLETO	2025-07-28 23:55:14.195	2025-10-07 22:11:56.459
67d28703-dbfa-476d-ab64-d84a6126df6f	4a2d7176-3f9d-43da-9a7f-e97d08f54744	e11fb842-8af1-44f8-83ef-8455f8c42f54	BM-1759875116484-19	DELIVERED	135.80	Rua 115, 27	6.00	FAILED	CREDIT_CARD	2025-07-15 18:19:17.216	2025-10-07 22:11:56.485
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patients (id, client_id, name, email, phone, document, birth_date, gender, address, city, state, zip_code, blood_type, allergies, medications, medical_history, emergency_contact, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, client_id, customer_id, order_id, payment_number, method, status, amount, currency, gateway, gateway_id, gateway_data, pix_key, pix_qr_code, card_last4, card_brand, installments, due_date, paid_at, failed_at, refunded_at, notes, failure_reason, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_variants (id, product_id, name, sku, size, color, material, attributes, price, compare_price, stock, images, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, client_id, category_id, name, description, price, image, sku, stock, "minStock", "isActive", "isFeatured", "createdAt", "updatedAt", images) FROM stdin;
4e46f5eb-3366-4bfc-a7c9-fa3cbbae83ce	4a2d7176-3f9d-43da-9a7f-e97d08f54744	f44d19a0-943a-408c-9207-943c8312d3c3	Suplemento Vitamina D3	Vitamina D3 1000UI - 60 cápsulas	45.90	\N	BM-SYVIYLIM	12	0	t	f	2025-10-07 22:11:55.73	2025-10-07 22:11:55.73	{}
5d3bc880-ef86-419e-ba10-d2fb6a8dce82	4a2d7176-3f9d-43da-9a7f-e97d08f54744	573f1ab5-fed7-463a-b24d-008453049241	Whey Protein	Whey Protein 1kg - Chocolate	89.90	\N	BM-3UIVAG20	92	0	t	f	2025-10-07 22:11:55.768	2025-10-07 22:11:55.768	{}
cdf7d7fd-2ce8-4679-8d16-08f1285e48fa	4a2d7176-3f9d-43da-9a7f-e97d08f54744	93d85031-284e-43ff-a0d3-22b740498f05	Creatina Monohidratada	Creatina 300g - Pura	32.50	\N	BM-DDM3IDZT	94	0	t	f	2025-10-07 22:11:55.777	2025-10-07 22:11:55.777	{}
3106d727-0e11-43a9-91a9-60f0c2d754fd	4a2d7176-3f9d-43da-9a7f-e97d08f54744	9bc9ccf0-8d63-4f0b-814b-3c00be9f89cc	Multivitamínico	Multivitamínico Completo - 90 cápsulas	67.80	\N	BM-Z5X2XQCL	27	0	t	f	2025-10-07 22:11:55.784	2025-10-07 22:11:55.784	{}
8c27fc42-8544-438c-9b41-5eed38a46a5d	4a2d7176-3f9d-43da-9a7f-e97d08f54744	5c0075f5-40fa-4cd0-918a-7a3c363e7257	Ômega 3	Ômega 3 1000mg - 120 cápsulas	54.90	\N	BM-3ABKIFGZ	25	0	t	f	2025-10-07 22:11:55.791	2025-10-07 22:11:55.791	{}
287837fd-81d2-4a2a-bc58-96c41e6d18b0	4a2d7176-3f9d-43da-9a7f-e97d08f54744	3d041e0d-8d0b-481d-8d17-ee60dd323818	BCAA	BCAA 2:1:1 - 300g	78.90	\N	BM-5LNPSMDW	28	0	t	f	2025-10-07 22:11:55.797	2025-10-07 22:11:55.797	{}
2cd36091-7758-4eeb-ab2c-e2095ad5f96c	4a2d7176-3f9d-43da-9a7f-e97d08f54744	351cfdc5-ef83-4ae1-be37-413a49acf4e4	Glutamina	Glutamina 300g - Pó	42.90	\N	BM-7HXEN9FC	59	0	t	f	2025-10-07 22:11:55.804	2025-10-07 22:11:55.804	{}
cd5fcea4-ab53-4a98-8ab0-2c5a0a5b60ea	4a2d7176-3f9d-43da-9a7f-e97d08f54744	fc1ddd56-4614-4dc6-aab8-d3498c8608d8	Termogênico	Termogênico Natural - 60 cápsulas	65.90	\N	BM-CA2HJPGL	77	0	t	f	2025-10-07 22:11:55.811	2025-10-07 22:11:55.811	{}
8e02ee47-2c0e-4853-bfaf-15c015445511	4a2d7176-3f9d-43da-9a7f-e97d08f54744	089e6a8a-f650-4ac2-a927-a7fb2c24663e	Colágeno	Colágeno Hidrolisado - 300g	89.90	\N	BM-00DXQSLI	79	0	t	f	2025-10-07 22:11:55.819	2025-10-07 22:11:55.819	{}
7831ce34-e038-4d6b-bc4a-131a31f67c64	4a2d7176-3f9d-43da-9a7f-e97d08f54744	2465789c-11b4-49e0-a587-9f9676680a6b	Probiótico	Probiótico 30 cápsulas	58.90	\N	BM-IQ620N11	41	0	t	f	2025-10-07 22:11:55.825	2025-10-07 22:11:55.825	{}
d8283add-ca5c-48e1-8e3c-b188e50ed453	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ee83a168-cdf6-4d68-9a6b-44e566ff6c1f	Magnésio	Magnésio Quelato - 60 cápsulas	35.90	\N	BM-HEQTYBBP	99	0	t	f	2025-10-07 22:11:55.832	2025-10-07 22:11:55.832	{}
46deb9d9-fa49-4ded-aa59-5162256b0a6a	4a2d7176-3f9d-43da-9a7f-e97d08f54744	866fc547-83ee-4f6f-92e1-17dcf5f6b5be	Zinco	Zinco 15mg - 60 cápsulas	28.90	\N	BM-AKOA9NLU	16	0	t	f	2025-10-07 22:11:55.839	2025-10-07 22:11:55.839	{}
4e2d4d34-40af-470f-9e09-efefba2710dd	4a2d7176-3f9d-43da-9a7f-e97d08f54744	e741bf8a-c6a6-4b63-8240-a4e27feb4611	Vitamina C	Vitamina C 1000mg - 60 cápsulas	32.90	\N	BM-SQ67WIFK	70	0	t	f	2025-10-07 22:11:55.847	2025-10-07 22:11:55.847	{}
e0e234c0-2dc1-4b42-8bec-54d7f46e7c4b	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ffb95baa-2d64-48f0-9bc2-4202636079f2	Ferro	Ferro Quelato - 60 cápsulas	39.90	\N	BM-UNBRXN3J	89	0	t	f	2025-10-07 22:11:55.854	2025-10-07 22:11:55.854	{}
a0d0e8f4-664e-440c-9e8c-c95cbc4fd2ad	4a2d7176-3f9d-43da-9a7f-e97d08f54744	5ed91df4-1dc7-4de2-b79c-165293c82ccd	Cálcio	Cálcio + Vitamina D - 60 cápsulas	48.90	\N	BM-BA7S3LHU	18	0	t	f	2025-10-07 22:11:55.86	2025-10-07 22:11:55.86	{}
ff371e7c-50c5-4003-aa16-0be2ce9e0171	4a2d7176-3f9d-43da-9a7f-e97d08f54744	93b97878-8d73-42cd-8a0d-4687ad3b8c1c	Biotina	Biotina 10mg - 60 cápsulas	42.90	\N	BM-XV1BJF4H	66	0	t	f	2025-10-07 22:11:55.866	2025-10-07 22:11:55.866	{}
c2e680c8-58b3-40ec-a014-851b282cb295	4a2d7176-3f9d-43da-9a7f-e97d08f54744	35bf6ebe-3104-4618-9113-9597a0da0591	Coenzima Q10	Coenzima Q10 100mg - 60 cápsulas	78.90	\N	BM-B7GYAHNU	21	0	t	f	2025-10-07 22:11:55.873	2025-10-07 22:11:55.873	{}
6d9c089c-87cd-4aa7-96a1-d8d312185918	4a2d7176-3f9d-43da-9a7f-e97d08f54744	69c7c5ed-fd2a-46c7-8299-19ac87386bda	Melatonina	Melatonina 3mg - 60 cápsulas	35.90	\N	BM-KSCEVYQF	92	0	t	f	2025-10-07 22:11:55.879	2025-10-07 22:11:55.879	{}
690b84ad-d919-48cf-9d3b-8efd002bd8df	4a2d7176-3f9d-43da-9a7f-e97d08f54744	cdaf5cfc-44ca-4fba-a2a3-c7274be01008	Ashwagandha	Ashwagandha 500mg - 60 cápsulas	58.90	\N	BM-L5PMQTNO	72	0	t	f	2025-10-07 22:11:55.886	2025-10-07 22:11:55.886	{}
1a493301-2eda-4d3c-940a-df5e740a0ae4	4a2d7176-3f9d-43da-9a7f-e97d08f54744	5b584896-d565-4f80-b8f0-1475c09e0d89	Curcumina	Curcumina 500mg - 60 cápsulas	45.90	\N	BM-4Q480JNQ	13	0	t	f	2025-10-07 22:11:55.893	2025-10-07 22:11:55.893	{}
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.properties (id, client_id, title, description, type, status, address, city, state, zip_code, neighborhood, bedrooms, bathrooms, area, parking_spots, price, "rentPrice", condo_fee, iptu, images, virtual_360, amenities, features, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: property_leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.property_leads (id, property_id, client_id, name, email, phone, message, source, status, priority, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: property_visits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.property_visits (id, property_id, client_id, visitor_name, visitor_email, visitor_phone, scheduled_at, status, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (id, user_id, token, "expiresAt", "createdAt") FROM stdin;
9255b2a7-6521-495b-9cae-83acde920118	16b7a8de-b0b4-467e-9af4-1db28c3719ca	7ef49cb2-c0e6-44a8-be13-849e9a452acc	2025-09-02 16:59:01.769	2025-08-26 16:59:01.77
4daa3269-8ca8-4e7b-a52f-9a5a1d2dee24	16b7a8de-b0b4-467e-9af4-1db28c3719ca	32424498-3748-49bf-b408-0bab865b23a3	2025-09-02 17:02:09.235	2025-08-26 17:02:09.236
2b813dc0-910b-41b3-9959-3b0c18512abc	16b7a8de-b0b4-467e-9af4-1db28c3719ca	d15798fe-8152-4350-a2a6-bf308134ddec	2025-09-02 17:02:19.474	2025-08-26 17:02:19.475
f8d4e2f2-ed19-406b-81de-e99f6d22188d	16b7a8de-b0b4-467e-9af4-1db28c3719ca	fec6eba7-6361-4d77-bab8-89239569f569	2025-09-02 17:05:30.981	2025-08-26 17:05:30.982
ff27f642-f868-49e4-a65b-9fb5f5143072	16b7a8de-b0b4-467e-9af4-1db28c3719ca	58449c96-298f-4647-aac4-f53f1eeddaba	2025-09-02 17:08:14.382	2025-08-26 17:08:14.383
65adfa29-07e0-4213-bcc8-c774e97e31a1	16b7a8de-b0b4-467e-9af4-1db28c3719ca	98ee78d9-5a86-4b55-897e-e83a073a0dc2	2025-09-02 17:13:50.904	2025-08-26 17:13:50.917
33cb2003-ad56-4193-a4a1-6f346e456f69	16b7a8de-b0b4-467e-9af4-1db28c3719ca	af5b2cbd-1bf2-4559-80a5-de51e959033c	2025-09-02 17:13:51.916	2025-08-26 17:13:51.922
2dc63ff6-bbed-4bb0-882a-6d8670735578	16b7a8de-b0b4-467e-9af4-1db28c3719ca	51ee2973-13ef-48d5-bb1f-21de87bced45	2025-09-02 17:14:25.26	2025-08-26 17:14:25.261
9775b655-2c1e-493d-b904-cf4611a53f15	16b7a8de-b0b4-467e-9af4-1db28c3719ca	6db2d3e0-b695-4ce2-af8f-870c9cbab289	2025-09-02 17:14:40.219	2025-08-26 17:14:40.22
3c5d753c-08d6-47df-9b56-c3f861347fd5	16b7a8de-b0b4-467e-9af4-1db28c3719ca	bf83b4c1-12fa-4c0e-b941-5715da610362	2025-09-02 17:15:07.083	2025-08-26 17:15:07.085
5eccf6c0-77dd-48c3-bc02-8833372a970b	16b7a8de-b0b4-467e-9af4-1db28c3719ca	f589c625-55de-486f-a871-f1a187ff74ae	2025-09-02 17:17:35.534	2025-08-26 17:17:35.536
b3f6bfbf-909c-40a5-8d77-b3fa201078a7	16b7a8de-b0b4-467e-9af4-1db28c3719ca	a0a41337-88cf-4c25-9055-86875b81e7a0	2025-09-02 17:19:07.802	2025-08-26 17:19:07.803
7f918732-05ca-47a4-afa0-1551b9039ab1	16b7a8de-b0b4-467e-9af4-1db28c3719ca	91c85c99-8064-425f-88cf-069cf6cc594d	2025-09-02 17:19:40.533	2025-08-26 17:19:40.534
d08b1a48-fcb2-4395-8cd8-e6775bd36cb6	16b7a8de-b0b4-467e-9af4-1db28c3719ca	ecc30229-c7d1-4811-8464-9c6b28153fa0	2025-09-02 17:19:53.359	2025-08-26 17:19:53.36
7c2babce-112c-4feb-9394-02864a854faf	16b7a8de-b0b4-467e-9af4-1db28c3719ca	3cdc3657-e3f7-4aae-865e-c6aa04190f75	2025-09-03 15:12:26.538	2025-08-27 15:12:26.552
c356f698-3105-4acc-85f4-b00c1ece8cb4	16b7a8de-b0b4-467e-9af4-1db28c3719ca	045c9cf3-5757-4615-8442-8ef193bca42f	2025-09-03 15:30:50.661	2025-08-27 15:30:50.662
29dded9c-40bd-4846-a1c3-af51fd0d05b1	16b7a8de-b0b4-467e-9af4-1db28c3719ca	741e5a13-fbae-4318-b4ac-5cd0f7260197	2025-09-03 15:50:16.994	2025-08-27 15:50:16.995
ae45374a-1c0b-41ec-94c9-f0b7fde7e364	16b7a8de-b0b4-467e-9af4-1db28c3719ca	9983d547-b6ac-4376-b5b2-4e78a165855a	2025-09-03 18:18:19.337	2025-08-27 18:18:19.338
669fcbb8-e89e-4330-aebb-d32cb6014b40	16b7a8de-b0b4-467e-9af4-1db28c3719ca	1435e9bf-ceb4-490b-bcf0-f95418ba79cf	2025-09-03 18:45:20.908	2025-08-27 18:45:20.91
94fda35a-7577-489e-8003-40f7b2332118	16b7a8de-b0b4-467e-9af4-1db28c3719ca	1fea8d3a-c9c7-4446-91d5-9560be00563a	2025-09-03 19:43:55.019	2025-08-27 19:43:55.021
247825b4-956d-4b16-97fb-53b29c01b38d	16b7a8de-b0b4-467e-9af4-1db28c3719ca	0ac1520f-657c-4c3f-9f0e-1a21914ef2ea	2025-09-03 20:02:57.221	2025-08-27 20:02:57.224
e81cc8d3-ab53-480f-93e2-ae9b0f013189	16b7a8de-b0b4-467e-9af4-1db28c3719ca	54ab2fe9-360a-4a75-8a1d-4b1210fdb7d5	2025-09-03 23:40:42.509	2025-08-27 23:40:42.511
4ac3f1a3-9c6a-483e-96f4-0ed3dd310c50	16b7a8de-b0b4-467e-9af4-1db28c3719ca	db64febb-1326-45f4-af70-b9fb1c78355c	2025-09-03 23:56:17.283	2025-08-27 23:56:17.284
4ed7d130-2d09-46a2-9105-83df8078c3cd	16b7a8de-b0b4-467e-9af4-1db28c3719ca	244ca112-0f85-4ba3-90d8-74c9723e3723	2025-09-04 02:06:02.831	2025-08-28 02:06:02.833
a3631a41-f9df-4226-94cc-28c2ea4342d8	16b7a8de-b0b4-467e-9af4-1db28c3719ca	6d063d0c-180d-40cb-8543-71cc5f09cc7c	2025-09-04 02:12:56.696	2025-08-28 02:12:56.698
a110e09d-b35e-4eba-ad1e-b68bdab77d37	16b7a8de-b0b4-467e-9af4-1db28c3719ca	937f906b-77bf-444d-ac2d-9c858478a854	2025-09-04 02:18:33.638	2025-08-28 02:18:33.639
b17a0b2b-4cba-49d7-8974-9c8c38be08af	16b7a8de-b0b4-467e-9af4-1db28c3719ca	3a19c498-209f-43e8-bf2b-5a24a8a3b5b5	2025-09-04 17:33:01.117	2025-08-28 17:33:01.122
2fd7c532-be5f-43ba-8b99-d168a27fd4ec	16b7a8de-b0b4-467e-9af4-1db28c3719ca	8336db2e-cb4f-44ea-b3e9-ebe23e42345b	2025-09-04 18:21:15.609	2025-08-28 18:21:15.612
f2c96d09-3551-4322-90c7-9b6b52a68794	16b7a8de-b0b4-467e-9af4-1db28c3719ca	e97c541b-06ee-49c1-adef-806a03d320fc	2025-09-04 18:28:13.297	2025-08-28 18:28:13.298
161b3995-8994-45bf-aed3-693d08c63ff4	16b7a8de-b0b4-467e-9af4-1db28c3719ca	1c63943e-b38d-4f1d-ae44-661d4ed1214e	2025-09-04 18:35:22.858	2025-08-28 18:35:22.859
dbe6e516-dd64-4008-aac2-d75a9ef38508	16b7a8de-b0b4-467e-9af4-1db28c3719ca	1e8c6d2e-0bcf-4996-91d9-2c95716769f8	2025-09-04 18:37:43.563	2025-08-28 18:37:43.564
6afb080d-57cd-4a8f-b5cd-c546bf281bff	16b7a8de-b0b4-467e-9af4-1db28c3719ca	70a2c2fd-cf14-4704-a273-f8951b193253	2025-09-04 19:15:33.956	2025-08-28 19:15:33.959
af114a8f-7c74-43f0-8907-435e15168b46	16b7a8de-b0b4-467e-9af4-1db28c3719ca	8c1d8b4f-c142-4205-bde2-6a9b3ec658b8	2025-09-04 19:44:48.154	2025-08-28 19:44:48.155
c4c032ee-c635-45ca-9043-63fb3c04af60	16b7a8de-b0b4-467e-9af4-1db28c3719ca	28964a83-5884-4f2a-8ded-c23e74f24b9a	2025-09-04 19:59:53.063	2025-08-28 19:59:53.065
9df30029-41f6-4eef-98fa-880c85c6ba2c	16b7a8de-b0b4-467e-9af4-1db28c3719ca	077360d0-ee9f-4da1-830c-59e34b9af145	2025-09-04 20:07:01.753	2025-08-28 20:07:01.755
2686cb9d-4189-4d88-bb1b-c93a4bb5335f	16b7a8de-b0b4-467e-9af4-1db28c3719ca	499048ea-783b-4787-b03d-17f5d5166ec7	2025-09-04 22:21:24.402	2025-08-28 22:21:24.406
a72fef49-b3f8-40e3-bfde-efb204edaa5d	16b7a8de-b0b4-467e-9af4-1db28c3719ca	b97d6ecb-90b3-4746-b03c-c81096628e2c	2025-09-04 22:30:30.345	2025-08-28 22:30:30.346
a7dd2455-11dc-4295-bbe0-848ffcea8187	16b7a8de-b0b4-467e-9af4-1db28c3719ca	96856c90-d0e0-4316-b890-16484e96ba7b	2025-09-04 22:51:53.102	2025-08-28 22:51:53.104
a1024e78-d18f-4ca1-b507-e8c0ec099236	16b7a8de-b0b4-467e-9af4-1db28c3719ca	8406f942-efb8-47ac-98ed-03956cee9f3e	2025-09-04 23:57:40.147	2025-08-28 23:57:40.15
ca885b81-657f-4053-aa26-2d5f65859adf	16b7a8de-b0b4-467e-9af4-1db28c3719ca	5ca21a0b-de2e-4165-8591-f15030753433	2025-09-05 00:20:45.394	2025-08-29 00:20:45.397
6c394867-aff7-41a6-a38e-534a7ff6262b	16b7a8de-b0b4-467e-9af4-1db28c3719ca	668172e5-0418-497e-af78-069a8c693fa0	2025-09-05 00:23:59.488	2025-08-29 00:23:59.49
789350ab-d977-4fe7-a317-e929f41bf8bc	16b7a8de-b0b4-467e-9af4-1db28c3719ca	a718fbbe-ad65-4c4a-aec6-d4b47ba174e7	2025-09-05 23:35:12.855	2025-08-29 23:35:12.858
65933eea-e440-4b01-96a7-7409fc8d1e3d	16b7a8de-b0b4-467e-9af4-1db28c3719ca	1d813ed3-3d63-40da-991e-5b9bbf39e3cd	2025-09-07 15:12:22.153	2025-08-31 15:12:22.162
1b9b08e2-bf2e-45ad-b2f0-ac981ea2d125	16b7a8de-b0b4-467e-9af4-1db28c3719ca	54574261-c9e8-46e9-8ced-00dc63215493	2025-09-07 18:37:30.084	2025-08-31 18:37:30.086
d9906870-a6a6-46e0-b0ae-66eba6cc50ec	16b7a8de-b0b4-467e-9af4-1db28c3719ca	188f1ed4-aaaf-4e38-a19f-c5fa12965e1b	2025-09-07 18:40:51.679	2025-08-31 18:40:51.681
e6b13748-2c06-4d81-a1e8-6040907f9b29	16b7a8de-b0b4-467e-9af4-1db28c3719ca	b256b824-881e-4405-b07a-f7ac4c48ae57	2025-09-07 19:29:04.993	2025-08-31 19:29:04.997
43a51f23-92f5-4202-ba61-d8738058fbf6	16b7a8de-b0b4-467e-9af4-1db28c3719ca	86ebdade-33b9-4809-93c7-4acfe9764210	2025-09-09 23:00:15.789	2025-09-02 23:00:15.791
4aba0ec4-e556-4f16-a8dc-d7ab7da16eb1	16b7a8de-b0b4-467e-9af4-1db28c3719ca	0dc05b86-aefe-4d6f-a0c7-8258d4fd191a	2025-09-10 02:26:46.946	2025-09-03 02:26:46.948
d406666e-5ce3-4cfd-a5d6-58d7395ae3f7	f3859b39-51dd-496e-b4fc-332457dbfab1	2e8d2eeb-f821-4927-a6e9-0880a387dc1d	2025-09-11 15:02:52.957	2025-09-04 15:02:52.959
a906fe03-2358-49ea-8b5c-b2d1f650b14f	f3859b39-51dd-496e-b4fc-332457dbfab1	c168f544-0dda-4f84-9b54-3f7b881000c4	2025-09-11 15:05:20.901	2025-09-04 15:05:20.902
a8cf9cc9-fe40-4c71-a31e-26b0ef77992b	f3859b39-51dd-496e-b4fc-332457dbfab1	55ea3351-d01e-4f9f-9a72-fb51429de7b9	2025-09-11 15:06:27.576	2025-09-04 15:06:27.577
442b2d91-0946-4253-8dab-3db25d589ae6	16b7a8de-b0b4-467e-9af4-1db28c3719ca	c303ed74-6622-4a67-b259-8e7cbc9c23aa	2025-09-11 15:07:35.241	2025-09-04 15:07:35.242
b71daaf7-2d0b-4ce5-bd7d-4d8e144a552e	f3859b39-51dd-496e-b4fc-332457dbfab1	fbb26a81-aa32-45cd-848f-274822b68b2f	2025-09-11 16:45:50.269	2025-09-04 16:45:50.272
f656fa46-f5b2-47ab-9860-fd65d9d5b45d	136dd0e8-cca6-484c-ab13-42b23049de39	3e0946c9-e653-4c70-bd57-130b672f7705	2025-09-12 15:39:08.936	2025-09-05 15:39:08.941
dd99dd3f-6e3f-4392-8ab7-4ceb29b5f6df	16b7a8de-b0b4-467e-9af4-1db28c3719ca	67901b25-4719-4c28-bb11-1274494238b3	2025-09-13 20:39:15.775	2025-09-06 20:39:15.778
b4c3bc4e-b432-4412-90c5-4754d34ab603	0b68319d-a3c2-4a6a-888d-27b732f7bca5	484e1a66-89fe-42d1-84b7-fb64e2339d5a	2025-10-02 23:59:02.252	2025-09-25 23:59:02.254
b872ddb8-88bf-425b-bb79-126f0cc5c091	0b68319d-a3c2-4a6a-888d-27b732f7bca5	ed886aa2-948e-4929-a7a5-81b9a45dbef3	2025-10-03 00:04:15.86	2025-09-26 00:04:15.862
1e22ae26-1ea3-4b8a-8630-15d2e599506d	0b68319d-a3c2-4a6a-888d-27b732f7bca5	5db3f45a-eec1-4dd3-9a7b-13481cad7821	2025-10-03 11:45:12.841	2025-09-26 11:45:12.842
16af846b-3bc8-453c-b752-cac1114ffcb6	a4886bc8-8d6d-41bf-a759-ca82428e0b73	24438047-8695-44b9-92a6-ad21d7811be2	2025-10-03 22:18:14.159	2025-09-26 22:18:14.16
8519546b-2a5e-41b4-b7a8-a4b0e430e02e	0b68319d-a3c2-4a6a-888d-27b732f7bca5	f4542c41-7989-4326-9540-8379b5475fec	2025-10-03 22:19:13.461	2025-09-26 22:19:13.462
8f127c37-d4dd-406c-beb5-50c14f1686f4	a4886bc8-8d6d-41bf-a759-ca82428e0b73	db306439-847a-427c-8178-8b9b0982867b	2025-10-03 22:21:04.182	2025-09-26 22:21:04.184
bfc6c387-3df2-44b1-b3bd-c89f3d25ec3f	0b68319d-a3c2-4a6a-888d-27b732f7bca5	bd0d37d6-4197-436a-a263-49efba407902	2025-10-03 22:21:33.613	2025-09-26 22:21:33.615
afc4acaf-a81a-4a0c-8336-6d29f4843239	a500fe01-6b64-4e66-afc1-283225cf478d	8bd9bdd4-96f1-4db0-bb88-8cc99049b6e7	2025-10-03 22:34:10.443	2025-09-26 22:34:10.444
cd5c3271-bb5a-4cbf-803b-6b57a2a13b12	0b68319d-a3c2-4a6a-888d-27b732f7bca5	292fc651-457e-4d72-94fd-f75384f367c0	2025-10-03 22:39:06.502	2025-09-26 22:39:06.505
8d6ea1da-6498-4fe4-9b44-a49fb38c6614	037a7cdb-56a4-46ec-aad4-fb895524e60c	260beca7-6304-415a-bf1b-ae142295928d	2025-10-11 14:23:01.553	2025-10-04 14:23:01.555
0edf4d2a-4cac-4a43-8a2b-54d8d730a660	037a7cdb-56a4-46ec-aad4-fb895524e60c	e925fadb-5c4c-46de-a0e1-3c9dcbb0d710	2025-10-11 14:26:17.24	2025-10-04 14:26:17.242
bfa59a15-450f-4f78-8c2b-c8c86d8f8e34	037a7cdb-56a4-46ec-aad4-fb895524e60c	5dd94d8f-90fa-4356-84b6-33b242bae9e0	2025-10-11 14:30:45.018	2025-10-04 14:30:45.02
690648a5-c514-4c2e-a090-5782f75a0708	037a7cdb-56a4-46ec-aad4-fb895524e60c	6b2f5488-e49e-4d8e-8a5c-f5d58e5abb6a	2025-10-11 15:42:18.864	2025-10-04 15:42:18.865
b03eb033-ab39-432e-8707-6b2d5d894f7a	037a7cdb-56a4-46ec-aad4-fb895524e60c	fe050647-24f5-4b05-a1b0-6c355bf09348	2025-10-11 15:46:00.51	2025-10-04 15:46:00.513
9e7bd57e-20f1-480a-bc24-b27dcbb477e5	037a7cdb-56a4-46ec-aad4-fb895524e60c	8db13549-549b-4a7f-89ab-e31d4a02dcc2	2025-10-11 15:52:13.029	2025-10-04 15:52:13.03
58d752a5-eed9-4195-826e-557932d6b027	037a7cdb-56a4-46ec-aad4-fb895524e60c	ea736960-97b9-4d84-b55f-fd7a355f45f2	2025-10-11 15:55:22.578	2025-10-04 15:55:22.579
15bbbb7b-a7b7-4d70-ba8a-e54e4cc8f4ab	037a7cdb-56a4-46ec-aad4-fb895524e60c	33d09412-96cf-4b82-b016-b6d8da18a5e5	2025-10-12 00:24:37.941	2025-10-05 00:24:37.946
70c4ce20-0d67-428c-826e-2a2d0571ae42	037a7cdb-56a4-46ec-aad4-fb895524e60c	366ef99c-8722-4eda-ae0e-174e213e7ccb	2025-10-13 11:23:34.752	2025-10-06 11:23:34.756
58e2e688-5de8-4f29-b2a8-e286ce612e0b	037a7cdb-56a4-46ec-aad4-fb895524e60c	dbf8684d-6d68-45a1-badf-975b7b5af0f3	2025-10-13 12:16:16.546	2025-10-06 12:16:16.549
cbe7dfce-24db-4343-8a7b-af2c7fce3599	037a7cdb-56a4-46ec-aad4-fb895524e60c	3141fcb5-d006-4a24-8b43-9a7e4a404a3f	2025-10-13 12:16:41.649	2025-10-06 12:16:41.657
b54da756-438a-4a1a-a6c2-abddb0270bd0	037a7cdb-56a4-46ec-aad4-fb895524e60c	d14ba78e-547d-49e5-855c-fb8915980e7b	2025-10-13 14:08:06.183	2025-10-06 14:08:06.186
bd7a9e87-9ea5-438d-9ade-de486ae86af8	037a7cdb-56a4-46ec-aad4-fb895524e60c	e5273a8a-b6ea-4468-b58f-659c4539fd3d	2025-10-14 22:12:07.952	2025-10-07 22:12:07.954
95118334-3329-40a4-b82f-a5314286bb26	037a7cdb-56a4-46ec-aad4-fb895524e60c	80e54435-856c-4e6d-9df6-8a43a3dd814c	2025-10-15 12:50:13.633	2025-10-08 12:50:13.634
fab4c220-d171-4a0d-a373-1c60bd1ebbe7	037a7cdb-56a4-46ec-aad4-fb895524e60c	d41b90f5-8399-4389-ae69-a807d5221137	2025-10-15 14:47:45.605	2025-10-08 14:47:45.608
541108ea-989b-480b-8fc3-1dca8d54c0c0	037a7cdb-56a4-46ec-aad4-fb895524e60c	199f8237-2dc9-4d6b-a607-c10d3ce557ce	2025-10-15 22:54:53.764	2025-10-08 22:54:53.775
f37d69fa-c443-4c1a-a771-c61a852a376b	037a7cdb-56a4-46ec-aad4-fb895524e60c	fec4e76c-4eb3-41f8-a948-36fee843450e	2025-10-16 00:00:53.248	2025-10-09 00:00:53.249
d23da149-26e9-4591-b9f8-d9fbd06952c8	037a7cdb-56a4-46ec-aad4-fb895524e60c	feb464fd-f1b7-4567-af4d-c5d5812afd1b	2025-10-16 00:37:42.203	2025-10-09 00:37:42.208
ca2b7255-783e-4809-8242-ab2d0baf3c6e	037a7cdb-56a4-46ec-aad4-fb895524e60c	9b90f6cc-02fb-49ae-bf8a-69bbe69f79db	2025-10-16 13:37:27.813	2025-10-09 13:37:27.816
ebd0c648-1680-488b-bba9-d8c1b9d49d62	037a7cdb-56a4-46ec-aad4-fb895524e60c	5951d77d-d433-4db3-a511-6c573c70fc98	2025-10-16 14:03:13.572	2025-10-09 14:03:13.573
bdc46152-51cf-4ec2-8099-7b393b430017	037a7cdb-56a4-46ec-aad4-fb895524e60c	23d7d6a0-fc29-4cc6-bb96-ae51a052e41e	2025-10-16 14:05:34.695	2025-10-09 14:05:34.722
4230f567-5bd9-477e-9e5b-5a35b060eb5f	037a7cdb-56a4-46ec-aad4-fb895524e60c	72325b95-aead-4918-920e-b9eda556b239	2025-10-16 21:32:05.049	2025-10-09 21:32:05.058
3b58533a-ef45-46e5-b086-9536a642694f	037a7cdb-56a4-46ec-aad4-fb895524e60c	160acde7-61e0-4ad9-b89f-6d634f504a02	2025-10-16 22:55:33.148	2025-10-09 22:55:33.161
9693675e-d72b-4639-b840-ff12970599e4	037a7cdb-56a4-46ec-aad4-fb895524e60c	340e4332-f829-49ae-8ce2-06b2d165a2fd	2025-10-16 23:13:03.884	2025-10-09 23:13:03.885
ee6c9315-186a-4e70-bf21-03f16c4e7ae0	037a7cdb-56a4-46ec-aad4-fb895524e60c	526c9c3a-9dda-4515-b63e-21d818c89d6c	2025-10-16 23:23:45.761	2025-10-09 23:23:45.763
548ac896-fba0-40d9-9bed-e7b4bad7e722	037a7cdb-56a4-46ec-aad4-fb895524e60c	1833db4b-5eea-4e73-aea3-a5720785bc98	2025-10-16 23:41:32.674	2025-10-09 23:41:32.688
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, product_id, customer_id, order_id, rating, title, comment, images, is_published, is_verified, response, responded_at, helpful_count, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedules (id, client_id, user_id, employee_id, date, title, description, tasks, status, priority, start_time, end_time, all_day, is_recurring, recurring_pattern, color, category, reminders, attachments, is_public, completed_at, created_at, updated_at) FROM stdin;
49962d31-54f9-4352-bf27-1b540edef972	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	16b7a8de-b0b4-467e-9af4-1db28c3719ca	\N	2025-09-02 03:00:00	teste1	aaaaaaa	"[]"	PENDING	MEDIUM	\N	\N	f	f	null	\N	WORK	"[]"	{}	f	\N	2025-09-07 14:11:23.346	2025-09-07 14:11:23.346
8c373784-ec29-44ec-832a-a507d26fbf56	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ceeaca49-e901-41d5-8c81-cc6cc09fd12e	\N	2025-10-18 17:00:00	Entrevista	Descrição detalhada do agendamento	[]	POSTPONED	URGENT	2025-10-18 17:00:00	2025-10-18 18:00:00	f	f	\N	#FFEAA7	APPOINTMENT	[]	{}	f	\N	2025-10-07 22:11:56.501	2025-10-07 22:11:56.501
9fc00cbc-207b-409b-b82d-6db85b1ace5a	4a2d7176-3f9d-43da-9a7f-e97d08f54744	74744d73-90be-48e9-9884-aa103a5f3f91	\N	2025-10-20 18:00:00	Treinamento	Descrição detalhada do agendamento	[]	COMPLETED	HIGH	2025-10-20 18:00:00	2025-10-20 21:00:00	f	f	\N	#96CEB4	PERSONAL	[]	{}	f	\N	2025-10-07 22:11:56.51	2025-10-07 22:11:56.51
32166f0a-54d7-4ecd-bc15-b59d117089a8	4a2d7176-3f9d-43da-9a7f-e97d08f54744	74744d73-90be-48e9-9884-aa103a5f3f91	\N	2025-10-09 14:00:00	Consulta Médica	Descrição detalhada do agendamento	[]	COMPLETED	HIGH	2025-10-09 14:00:00	2025-10-09 17:00:00	f	f	\N	#45B7D1	REMINDER	[]	{}	f	\N	2025-10-07 22:11:56.515	2025-10-07 22:11:56.515
0ef5b7fc-8888-4eb0-8260-df50da3e6476	4a2d7176-3f9d-43da-9a7f-e97d08f54744	92e3da2a-e84c-4093-b651-5f8b0d18ce40	\N	2025-09-28 13:45:00	Apresentação	Descrição detalhada do agendamento	[]	POSTPONED	URGENT	2025-09-28 13:45:00	2025-09-28 17:45:00	f	f	\N	#96CEB4	WORK	[]	{}	f	\N	2025-10-07 22:11:56.521	2025-10-07 22:11:56.521
e799523c-7402-4a3a-b61c-f6183e3ed766	4a2d7176-3f9d-43da-9a7f-e97d08f54744	1eb96f17-661e-4e37-8bcb-13371c91cebf	\N	2025-10-18 16:30:00	Consulta Médica	Descrição detalhada do agendamento	[]	CANCELLED	LOW	2025-10-18 16:30:00	2025-10-18 18:30:00	t	t	\N	#4ECDC4	WORK	[]	{}	f	\N	2025-10-07 22:11:56.526	2025-10-07 22:11:56.526
f0ec3de3-c698-4f8c-a169-931809ed8f15	4a2d7176-3f9d-43da-9a7f-e97d08f54744	f0743ac5-a52e-4eb3-ba18-72cb00013562	\N	2025-10-02 12:15:00	Avaliação de Produto	Descrição detalhada do agendamento	[]	PENDING	URGENT	2025-10-02 12:15:00	2025-10-02 16:15:00	f	t	\N	#FF6B6B	PERSONAL	[]	{}	f	\N	2025-10-07 22:11:56.533	2025-10-07 22:11:56.533
76e5721e-86fa-4880-a8e2-3c6c28de11fe	4a2d7176-3f9d-43da-9a7f-e97d08f54744	8925fab5-304c-4ee8-a791-5590dc43f806	\N	2025-10-18 16:30:00	Planejamento Estratégico	Descrição detalhada do agendamento	[]	COMPLETED	URGENT	2025-10-18 16:30:00	2025-10-18 17:30:00	f	t	\N	#FF6B6B	REMINDER	[]	{}	f	\N	2025-10-07 22:11:56.544	2025-10-07 22:11:56.544
af5de09e-2f22-48a4-8b53-2fe5337ac70c	4a2d7176-3f9d-43da-9a7f-e97d08f54744	e8dee565-9b3d-44bb-b0ca-090bf570dc56	\N	2025-09-25 11:15:00	Avaliação de Produto	Descrição detalhada do agendamento	[]	IN_PROGRESS	HIGH	2025-09-25 11:15:00	2025-09-25 15:15:00	t	t	\N	#45B7D1	PERSONAL	[]	{}	f	\N	2025-10-07 22:11:56.549	2025-10-07 22:11:56.549
f86bf75b-520f-4104-bbf5-8ae6aca5b8c1	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ed7d6ffb-8273-4316-8394-9ae757076482	\N	2025-10-20 12:45:00	Avaliação de Produto	Descrição detalhada do agendamento	[]	COMPLETED	LOW	2025-10-20 12:45:00	2025-10-20 14:45:00	f	t	\N	#FF6B6B	APPOINTMENT	[]	{}	f	\N	2025-10-07 22:11:56.553	2025-10-07 22:11:56.553
d1128695-9236-43d3-ae4b-279284236f68	4a2d7176-3f9d-43da-9a7f-e97d08f54744	ed7d6ffb-8273-4316-8394-9ae757076482	\N	2025-10-16 14:30:00	Reunião de Equipe	Descrição detalhada do agendamento	[]	PENDING	MEDIUM	2025-10-16 14:30:00	2025-10-16 16:30:00	t	t	\N	#FF6B6B	WORK	[]	{}	f	\N	2025-10-07 22:11:56.557	2025-10-07 22:11:56.557
d63eac65-1a9a-4b97-bd02-09a75d9e79d0	4a2d7176-3f9d-43da-9a7f-e97d08f54744	6396a192-2f09-49f8-9739-368e143c323b	\N	2025-09-26 18:15:00	Avaliação de Produto	Descrição detalhada do agendamento	[]	POSTPONED	URGENT	2025-09-26 18:15:00	2025-09-26 20:15:00	t	t	\N	#96CEB4	OTHER	[]	{}	f	\N	2025-10-07 22:11:56.56	2025-10-07 22:11:56.56
7137dea1-98df-4b20-9952-5c9137aaee58	4a2d7176-3f9d-43da-9a7f-e97d08f54744	488444ca-9356-4c3e-819e-a8ad0031005c	\N	2025-09-23 18:30:00	Entrevista	Descrição detalhada do agendamento	[]	POSTPONED	MEDIUM	2025-09-23 18:30:00	2025-09-23 19:30:00	f	t	\N	#FF6B6B	PERSONAL	[]	{}	f	\N	2025-10-07 22:11:56.564	2025-10-07 22:11:56.564
e61bb0c5-720d-4928-a5fd-441f697eab7a	4a2d7176-3f9d-43da-9a7f-e97d08f54744	354a6f84-c351-4329-91a9-15a4dd295951	\N	2025-09-28 18:30:00	Avaliação de Produto	Descrição detalhada do agendamento	[]	IN_PROGRESS	HIGH	2025-09-28 18:30:00	2025-09-28 22:30:00	f	f	\N	#45B7D1	PERSONAL	[]	{}	f	\N	2025-10-07 22:11:56.567	2025-10-07 22:11:56.567
8f169704-8797-44f2-b745-8290f9d664ef	4a2d7176-3f9d-43da-9a7f-e97d08f54744	1eb96f17-661e-4e37-8bcb-13371c91cebf	\N	2025-09-28 13:45:00	Revisão de Contratos	Descrição detalhada do agendamento	[]	POSTPONED	LOW	2025-09-28 13:45:00	2025-09-28 14:45:00	f	t	\N	#FFEAA7	MEETING	[]	{}	f	\N	2025-10-07 22:11:56.571	2025-10-07 22:11:56.571
cf07d6f8-25bb-4ce5-9275-a1425512e9fd	4a2d7176-3f9d-43da-9a7f-e97d08f54744	f0743ac5-a52e-4eb3-ba18-72cb00013562	\N	2025-09-26 09:00:00	Treinamento	Descrição detalhada do agendamento	[]	IN_PROGRESS	URGENT	2025-09-26 09:00:00	2025-09-26 11:00:00	f	f	\N	#45B7D1	REMINDER	[]	{}	f	\N	2025-10-07 22:11:56.574	2025-10-07 22:11:56.574
894d19cc-23c3-4122-aa7a-59eedc270f19	4a2d7176-3f9d-43da-9a7f-e97d08f54744	1ac729a4-f041-4aab-ac1d-d0958372dddc	\N	2025-10-11 10:15:00	Workshop	Descrição detalhada do agendamento	[]	CANCELLED	MEDIUM	2025-10-11 10:15:00	2025-10-11 11:15:00	f	t	\N	#45B7D1	MEETING	[]	{}	f	\N	2025-10-07 22:11:56.578	2025-10-07 22:11:56.578
55689971-17e1-4156-ae3f-1dac14ee0c2a	4a2d7176-3f9d-43da-9a7f-e97d08f54744	1d828c70-ca44-4e92-b30d-8cd2c0f2dc80	\N	2025-10-10 11:15:00	Feedback de Cliente	Descrição detalhada do agendamento	[]	POSTPONED	URGENT	2025-10-10 11:15:00	2025-10-10 13:15:00	f	t	\N	#45B7D1	APPOINTMENT	[]	{}	f	\N	2025-10-07 22:11:56.582	2025-10-07 22:11:56.582
be565fdb-a708-4efd-b6c8-ed9d87b3df1a	4a2d7176-3f9d-43da-9a7f-e97d08f54744	354a6f84-c351-4329-91a9-15a4dd295951	\N	2025-09-24 08:30:00	Reunião de Equipe	Descrição detalhada do agendamento	[]	PENDING	URGENT	2025-09-24 08:30:00	2025-09-24 12:30:00	t	f	\N	#96CEB4	WORK	[]	{}	f	\N	2025-10-07 22:11:56.586	2025-10-07 22:11:56.586
869ba51e-a554-41b5-b3de-df1164518340	4a2d7176-3f9d-43da-9a7f-e97d08f54744	74744d73-90be-48e9-9884-aa103a5f3f91	\N	2025-09-22 16:45:00	Revisão de Contratos	Descrição detalhada do agendamento	[]	COMPLETED	URGENT	2025-09-22 16:45:00	2025-09-22 19:45:00	f	f	\N	#96CEB4	APPOINTMENT	[]	{}	f	\N	2025-10-07 22:11:56.589	2025-10-07 22:11:56.589
1e9acaf8-41ef-4e26-a75b-9ec51b9a7e06	4a2d7176-3f9d-43da-9a7f-e97d08f54744	e11fb842-8af1-44f8-83ef-8455f8c42f54	\N	2025-10-14 11:00:00	Treinamento	Descrição detalhada do agendamento	[]	PENDING	MEDIUM	2025-10-14 11:00:00	2025-10-14 12:00:00	f	f	\N	#FFEAA7	REMINDER	[]	{}	f	\N	2025-10-07 22:11:56.594	2025-10-07 22:11:56.594
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name, description, duration, price, "isActive", "createdAt", "updatedAt", category_id, client_id) FROM stdin;
e19b26f7-6a38-4bf0-8e98-34deb4c5aaea	Sessão de Psicanálise	Atendimento individual com psicanalista especializado	60	250.00	t	2025-08-26 15:11:34.937	2025-08-26 15:11:34.937	30d50b8a-5d7f-4be9-a364-4fb70c4abded	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
451d01ca-5705-4c76-a58c-bd24bf3e6fa2	Consulta Psicológica	Sessão de terapia individual	50	169.00	t	2025-10-07 22:11:56.836	2025-10-07 22:11:56.836	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
eec9720a-84ab-4e54-a80b-3d283bd9ebbc	Avaliação Psicológica	Avaliação completa do paciente	90	287.00	t	2025-10-07 22:11:56.844	2025-10-07 22:11:56.844	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
ce43d141-7230-4f4f-a3ff-21b1b45a1af0	Terapia de Casal	Sessão de terapia para casais	60	142.00	t	2025-10-07 22:11:56.851	2025-10-07 22:11:56.851	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
3856e12e-7eeb-4029-9f79-9b2d2fb05b07	Terapia Familiar	Sessão de terapia familiar	75	232.00	t	2025-10-07 22:11:56.859	2025-10-07 22:11:56.859	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
daed6449-6ced-4ea0-a1a4-510cfb3064ca	Orientação Vocacional	Orientação para escolha profissional	60	156.00	t	2025-10-07 22:11:56.871	2025-10-07 22:11:56.871	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
3c3fe1bf-f9f5-43b0-a5f5-b988a0502b7e	Avaliação Neuropsicológica	Avaliação de funções cognitivas	120	117.00	t	2025-10-07 22:11:56.878	2025-10-07 22:11:56.878	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
3964fcc6-b5bf-4be5-b3c2-bfca76284f5c	Terapia Cognitivo-Comportamental	TCC individual	50	196.00	t	2025-10-07 22:11:56.882	2025-10-07 22:11:56.882	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
387bae8a-59a2-491d-9ed9-0afcf46c8afd	Grupo de Apoio	Sessão em grupo	90	218.00	t	2025-10-07 22:11:56.887	2025-10-07 22:11:56.887	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
32d39247-a92e-4fe0-b5e6-b1051a594906	Supervisão Clínica	Supervisão para profissionais	60	245.00	t	2025-10-07 22:11:56.891	2025-10-07 22:11:56.891	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
88c83bd5-234b-4f11-9d09-e58fe5e7e616	Psicodiagnóstico	Avaliação diagnóstica completa	120	131.00	t	2025-10-07 22:11:56.895	2025-10-07 22:11:56.895	\N	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8
\.


--
-- Data for Name: shared_data_audit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shared_data_audit (id, client_id, workspace_id, user_id, action, entity, entity_id, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: shipment_trackings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipment_trackings (id, shipment_id, status, message, location, datetime, "createdAt") FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipments (id, order_id, tracking_code, method, status, weight, width, height, length, cost, estimated_delivery, shipped_at, delivered_at, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, client_id, product_id, user_id, type, quantity, reason, unit_cost, total_cost, order_id, supplier_id, batch_number, expiry_date, "createdAt") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (id, client_id, name, document, email, phone, address, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, client_id, workspace_id, user_id, category_id, title, description, amount, type, status, date, is_recurring, recurring_pattern, tags, created_at, updated_at) FROM stdin;
515dedfc-e006-4b7e-a11d-790034f7e32f	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	e11fb842-8af1-44f8-83ef-8455f8c42f54	\N	Reembolso	Transação income - 10/7/2025	4759.00	INCOME	CONFIRMED	2025-09-17 22:24:58.852	f	\N	{}	2025-10-07 22:11:56.637	2025-10-07 22:11:56.637
66f64db2-964b-4a5f-9269-8ad3df1b0c65	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	354a6f84-c351-4329-91a9-15a4dd295951	\N	Comissão	Transação income - 10/7/2025	3533.00	INCOME	CANCELLED	2025-09-26 18:42:41.549	f	\N	{importante}	2025-10-07 22:11:56.645	2025-10-07 22:11:56.645
5b29a2aa-327d-4f52-a2b8-e7287c20071c	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	1ac729a4-f041-4aab-ac1d-d0958372dddc	\N	Marketing	Transação expense - 10/7/2025	-974.00	EXPENSE	CONFIRMED	2025-09-25 06:16:26.819	f	\N	{}	2025-10-07 22:11:56.651	2025-10-07 22:11:56.651
9d9e54f8-9542-4dd8-929e-cf70e0c1963a	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	3138a981-e63c-47ea-95b3-834a797af950	\N	Equipamentos	Transação expense - 10/7/2025	-688.00	EXPENSE	PENDING	2025-09-08 06:03:16.654	f	\N	{}	2025-10-07 22:11:56.655	2025-10-07 22:11:56.655
538faa37-97c5-4e46-9e92-61c6e91b01cc	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	74744d73-90be-48e9-9884-aa103a5f3f91	\N	Compra de Estoque	Transação expense - 10/7/2025	-1355.00	EXPENSE	PENDING	2025-09-23 06:34:26.636	f	\N	{mensal}	2025-10-07 22:11:56.658	2025-10-07 22:11:56.658
7806b5b8-7eb5-42e9-ac5c-eed5d18e5017	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	52f97c9f-e174-48f3-906c-4c13add2f47e	\N	Marketing	Transação expense - 10/7/2025	-1305.00	EXPENSE	CONFIRMED	2025-10-03 13:23:43.902	f	\N	{mensal}	2025-10-07 22:11:56.661	2025-10-07 22:11:56.661
94aa1db0-f348-4764-b19d-09ad8a84d609	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	094dad4e-77bb-49c7-8f6b-8043bc5520a6	\N	Salário	Transação expense - 10/7/2025	-3239.00	EXPENSE	PENDING	2025-09-10 22:56:10.168	f	\N	{urgente}	2025-10-07 22:11:56.666	2025-10-07 22:11:56.666
68c699c8-f8d1-49f9-91e7-a2cad4dd1406	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	ceeaca49-e901-41d5-8c81-cc6cc09fd12e	\N	Reembolso	Transação income - 10/7/2025	4459.00	INCOME	CONFIRMED	2025-09-22 10:57:17.428	f	\N	{mensal}	2025-10-07 22:11:56.669	2025-10-07 22:11:56.669
5e40e04b-9eed-494a-8c21-a180b145fc33	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	1eb96f17-661e-4e37-8bcb-13371c91cebf	\N	Compra de Estoque	Transação expense - 10/7/2025	-3243.00	EXPENSE	PENDING	2025-09-29 02:32:17.082	f	\N	{mensal}	2025-10-07 22:11:56.673	2025-10-07 22:11:56.673
7d982e6e-05f8-4469-9364-dfae1e5efa6b	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	8925fab5-304c-4ee8-a791-5590dc43f806	\N	Reembolso	Transação income - 10/7/2025	3108.00	INCOME	CANCELLED	2025-10-04 07:40:21.436	f	\N	{urgente}	2025-10-07 22:11:56.676	2025-10-07 22:11:56.676
da1bf7c9-b822-442e-82d6-a84467f8d7a9	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	3138a981-e63c-47ea-95b3-834a797af950	\N	Comissão	Transação income - 10/7/2025	3348.00	INCOME	CANCELLED	2025-09-09 07:50:47.613	f	\N	{}	2025-10-07 22:11:56.679	2025-10-07 22:11:56.679
1144690c-6d3d-4673-8851-9b07ce6de4bf	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	ed7d6ffb-8273-4316-8394-9ae757076482	\N	Venda de Produto	Transação income - 10/7/2025	4283.00	INCOME	CANCELLED	2025-10-03 16:09:03.718	f	\N	{urgente}	2025-10-07 22:11:56.683	2025-10-07 22:11:56.683
c869dcf6-bdd7-409a-a2a3-2d1c06979ed8	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	1eb96f17-661e-4e37-8bcb-13371c91cebf	\N	Salário	Transação expense - 10/7/2025	-2190.00	EXPENSE	PENDING	2025-09-08 19:49:17.308	f	\N	{importante}	2025-10-07 22:11:56.689	2025-10-07 22:11:56.689
b283fff0-dc47-439e-bb4f-8bf761c4c5db	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	ceeaca49-e901-41d5-8c81-cc6cc09fd12e	\N	Comissão	Transação income - 10/7/2025	3769.00	INCOME	CANCELLED	2025-09-28 07:29:57.624	f	\N	{importante}	2025-10-07 22:11:56.692	2025-10-07 22:11:56.692
ac9b61e2-6619-4fb5-9117-299e75d9ce38	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	40fc20f3-8517-4d1f-be27-45c6eff86e7f	\N	Salário	Transação expense - 10/7/2025	-1783.00	EXPENSE	PENDING	2025-09-27 10:16:23.498	f	\N	{urgente}	2025-10-07 22:11:56.697	2025-10-07 22:11:56.697
68b73d96-07c4-4cf4-8576-ae1d083ef608	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	ceeaca49-e901-41d5-8c81-cc6cc09fd12e	\N	Juros	Transação income - 10/7/2025	125.00	INCOME	CONFIRMED	2025-10-06 11:41:02.177	f	\N	{}	2025-10-07 22:11:56.701	2025-10-07 22:11:56.701
54490532-442f-4818-8676-b4707bca7a32	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	e11fb842-8af1-44f8-83ef-8455f8c42f54	\N	Reembolso	Transação income - 10/7/2025	4312.00	INCOME	CONFIRMED	2025-10-04 17:03:18.293	f	\N	{importante}	2025-10-07 22:11:56.705	2025-10-07 22:11:56.705
d82e4c8b-a0a7-4191-8f41-ab89c6944c6c	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	e11fb842-8af1-44f8-83ef-8455f8c42f54	\N	Marketing	Transação expense - 10/7/2025	-506.00	EXPENSE	PENDING	2025-09-13 19:37:28.599	f	\N	{urgente}	2025-10-07 22:11:56.709	2025-10-07 22:11:56.709
2d540bdb-3bd1-4b94-9582-1482c8176692	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	ceeaca49-e901-41d5-8c81-cc6cc09fd12e	\N	Marketing	Transação expense - 10/7/2025	-127.00	EXPENSE	CONFIRMED	2025-10-07 14:48:12.279	f	\N	{importante}	2025-10-07 22:11:56.713	2025-10-07 22:11:56.713
f84269a9-b244-4916-87fa-9897d1e79b6f	4a2d7176-3f9d-43da-9a7f-e97d08f54744	\N	40fc20f3-8517-4d1f-be27-45c6eff86e7f	\N	Compra de Estoque	Transação expense - 10/7/2025	-2305.00	EXPENSE	CANCELLED	2025-10-04 09:14:13.56	f	\N	{urgente}	2025-10-07 22:11:56.717	2025-10-07 22:11:56.717
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, client_id, name, email, phone, avatar, password, role, status, "failedLoginAttempts", "lockedUntil", "lastLogin", "emailVerified", "emailVerifiedAt", "emailVerificationToken", "passwordResetToken", "passwordResetTokenExpiresAt", "createdAt", "updatedAt", employee_id) FROM stdin;
f3859b39-51dd-496e-b4fc-332457dbfab1	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Gabriela Reis	gabrielamreis@hotmail.com	(11)99613-3022	/funcionarios/Gabriela Reis - Psicanalista Clínica.jpeg.jpg	$2b$10$SiP9HyQNghxbN9Kjzk4tj.FXqbp0/3JaItguZ5dudLdphus1XRzji	EMPLOYEE	ACTIVE	0	\N	2025-09-04 16:45:42.688	t	2025-09-04 15:04:52.593	\N	\N	\N	2025-08-26 15:11:34.7	2025-09-04 16:45:42.69	f9043087-dd32-4928-8690-ed149c0094ca
a4886bc8-8d6d-41bf-a759-ca82428e0b73	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Cristina	cristina@bemmecare.com		\N	$2b$12$DqEuBMwxeDX3hybjYsjYauN8oKX60GURZeZ8FZcEbNrKQd.KAcoam	ADMIN	ACTIVE	0	\N	2025-09-26 22:21:03.809	f	\N	\N	\N	\N	2025-09-26 22:18:14.131	2025-09-26 22:21:03.81	\N
a500fe01-6b64-4e66-afc1-283225cf478d	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Joao	joaoMiranda@bemmecare.com		\N	$2b$12$Bi3/emLiG3JToc.6z6SU3.NLPI2OuPjMSvTUDkV0CF/6wrG7JKbgm	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-09-26 22:34:10.428	2025-09-26 22:34:10.428	\N
16b7a8de-b0b4-467e-9af4-1db28c3719ca	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Admin Expatriamente	admin@expatriamente.com	\N	\N	$2b$10$tIl53w81tskRjNb3O4IqQuAROcHFbi.31ZRu1IGvE8G9LAKae4fUC	SUPER_ADMIN	ACTIVE	0	\N	2025-09-06 20:39:14.04	t	2025-08-26 15:11:34.465	\N	\N	\N	2025-08-26 15:11:34.467	2025-09-06 20:39:14.042	\N
136dd0e8-cca6-484c-ab13-42b23049de39	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Mary Louzas	mary.louzas@expatriamente.com	(12) 99723-9566	/funcionarios/Mary Louzas.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	2025-09-05 15:39:02.248	f	\N	\N	\N	\N	2025-08-26 15:11:34.806	2025-09-05 15:39:02.25	5cf13adf-483a-4967-add4-d830509386fc
bd2dc514-2191-4837-8e98-f94459676b6e	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Ademir Fragnani Jr	ademir.fragnani.jr@expatriamente.com	(19) 99999-8880	/funcionarios/Ademir Fragnani Junior.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.575	2025-08-26 15:11:34.598	c74c3663-0edb-445d-a7c1-ebffc4e801f0
6a90e636-1090-432a-bfb0-1c8ca7352439	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Anitta Carelli	anitta.carelli@expatriamente.com	(11) 98263-4538	/funcionarios/Anita Careli - psicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.605	2025-08-26 15:11:34.616	1d97c7bb-e720-4c04-a251-bb9343eba546
c625c174-5451-4045-96a6-793c8688f56c	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Carlos Henrique Mathias	carlos.henrique.mathias@expatriamente.com	(19) 98111-5101	/funcionarios/Carlos Henrique Mathias - Psicanalista Clínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.622	2025-08-26 15:11:34.631	a7e76494-1e3d-424a-8730-75dea10bbdb1
6fcba2a8-10a4-4c2c-9ab5-667194348eda	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Carla Truzzi	carla.truzzi@expatriamente.com	39 346 308-0785	/funcionarios/Ida Carla Truzzi - Psicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.637	2025-08-26 15:11:34.648	241d6e85-1a16-45cd-94c1-fb1e5fdad28b
cf28272c-4dd9-4b0f-96c9-677447458dce	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Carlos Quesada	carlos.quesada@expatriamente.com	(914) 656-9151	/funcionarios/Paulo Quesada de Almeida - Psicanalista CLínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.653	2025-08-26 15:11:34.663	a055bb1b-8880-4799-adf7-4fe462968169
fb9e3d08-d5bd-4fde-bfa3-a43921c3dab7	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Eduardo Louzas	eduardo.louzas@expatriamente.com	(12) 99787-7773	/funcionarios/Eduardo Louzas - Psicanalista Clínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.669	2025-08-26 15:11:34.679	40603111-2abe-4847-86fb-46e684fd7c32
9d318ec4-b828-457e-8ee9-897bc189ee08	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Elza Giorgi (Video)	elza.giorgi.video@expatriamente.com	(19) 98129-0884	/funcionarios/Elza pisicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.685	2025-08-26 15:11:34.694	fb96675d-7fb5-4ad1-850f-9af414743dc6
1fc3fdfa-f67c-412d-a799-be05e7cfbc5c	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	José Carlos Pires Júnior	jose.carlos.pires.junior@expatriamente.com	(11) 976026002	/funcionarios/Jose Carlos Pires Junior.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.716	2025-08-26 15:11:34.726	7c364568-2cfc-4b11-a925-3e048ee2282c
9e633398-5111-4098-b54a-583ff575de37	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Juliana Hipólito	juliana.hipolito@expatriamente.com	(19) 99967-7966	/funcionarios/Juliana Hipólito.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.731	2025-08-26 15:11:34.74	7f6759af-9863-493d-b4d9-3fc7f27ce627
7c7aebbd-ba6d-4d22-83c9-cb47f9ad16c7	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Juliano Casarin	juliano.casarin@expatriamente.com	(19) 99684-6555	/funcionarios/Juliano Casarin - psicanalista Clínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.746	2025-08-26 15:11:34.755	efd2f305-7f3b-47cb-9a54-543993946044
8ccb5d5c-2c27-4502-ac36-17cf59ebe374	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Laura Truzzi	laura.truzzi@expatriamente.com	(11) 99580-4327	/funcionarios/Laura Truzzi - Psicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.76	2025-08-26 15:11:34.77	a33bd12f-0975-4cff-bc76-b44e6ef20d82
0a78fd74-623e-41ec-a0c4-967d9d1eac4b	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Marina Valente	marina.valente@expatriamente.com	(19) 98850-1868	/funcionarios/Mariana Valente - Psicanalista CLínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.775	2025-08-26 15:11:34.783	8d23d3b8-6e20-4578-a503-07e9e2a2dcd6
9b5411c4-fa13-4cfe-931f-4be19d602a23	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Masayuki	masayuki@expatriamente.com	(11) 99386-1655	/funcionarios/Masayuki Kawakami - Psicanalista Clínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.788	2025-08-26 15:11:34.801	624659b3-9523-47ff-ae65-f82d4f292464
181fe581-efa3-4963-923e-35e0b3d7e494	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Milton Domingues	milton.domingues@expatriamente.com	(19) 99496-2777	/funcionarios/Milton Domingues - Psicanalista Clínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.822	2025-08-26 15:11:34.832	ebd9a8a0-711e-4052-a73e-9309f8aa4531
a5f4839c-22ea-4beb-aa77-01f083e23830	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Paula Volpe	paula.volpe@expatriamente.com	(11) 98555-6496	/funcionarios/Paula Volpe - Psicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.836	2025-08-26 15:11:34.845	85cb2fba-fc32-4bcc-bc49-0e773c973f2a
dbf20ba6-cd05-494f-9960-d0747ae8e799	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Paula Carelli de Noronha Peres	paula.carelli.de.noronha.peres@expatriamente.com	(19) 99602-6867	/funcionarios/Paula Carelli de Noronha Peres - Psicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.849	2025-08-26 15:11:34.857	48d062be-5d0a-4211-849e-15dbb8b3b296
0b68319d-a3c2-4a6a-888d-27b732f7bca5	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Guillermo	guillermo@bemmecare.com		\N	$2b$12$57CEDKGC/aHg8Uo8h/BZmeJE9HjMiIJN813nl/cNZPaGeRHB4tXca	SUPER_ADMIN	ACTIVE	0	\N	2025-09-26 22:39:05.498	f	\N	\N	\N	\N	2025-09-25 23:59:02.213	2025-09-26 22:39:05.499	\N
4401a10e-7370-4f84-b770-0f6884077d73	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Pedro Arruda	pedro.arruda@expatriamente.com	(21) 99692-5439	/funcionarios/Pedro Aramis Arruda - Psicanalista Clínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.862	2025-08-26 15:11:34.871	0a05bfe7-fc10-44fe-85bd-bc0544944c0a
0a7d1d69-06cc-4648-8480-e399f843d523	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Sylvia Maluf	sylvia.maluf@expatriamente.com	(11) 98555-1212	/funcionarios/Sylvia Duarte Maluf - Psicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.875	2025-08-26 15:11:34.885	2c4b2f18-8788-42aa-a91d-5d3495b86d87
a480f5f8-9be3-461d-879d-52e8c05bddb3	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Tacyana Salomão	tacyana.salomao@expatriamente.com	(11) 91236-8270	/funcionarios/Tacyana Salomão - Psicanalista Clínica.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.889	2025-08-26 15:11:34.898	c1919450-b3d3-4aeb-9366-d85419a8e0ca
7a7c0ac0-1b54-45d6-a9af-047492bf80ef	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Vilma Zotareli	vilma.zotareli@expatriamente.com	(19) 98122-3408	/funcionarios/Vilma Zotareli - Psicanalista Clínico.jpeg.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.903	2025-08-26 15:11:34.912	307f6e5c-b314-4a3c-92e6-84364dc8eab0
9639f73a-b536-434a-8f7d-53257703e506	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Waldomiro N. Santos	waldomiro.n.santos@expatriamente.com	(19) 99998-9587	/funcionarios/Waldomiro Santos.jpg	$2b$10$QVuAvi9FhuCt1Jnw5gD41OtZmec2Ik9v1U/lKFBC7aytKTiVtRqRW	EMPLOYEE	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-08-26 15:11:34.917	2025-08-26 15:11:34.925	f0c243dc-cb38-448a-a8d1-4237884cc67f
354a6f84-c351-4329-91a9-15a4dd295951	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Ana Silva	ana.silva@email.com	+55 11 99999-0001	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.901	2025-10-07 22:11:55.901	\N
e8dee565-9b3d-44bb-b0ca-090bf570dc56	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Carlos Santos	carlos.santos@email.com	+55 11 99999-0002	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.916	2025-10-07 22:11:55.916	\N
1d828c70-ca44-4e92-b30d-8cd2c0f2dc80	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Maria Oliveira	maria.oliveira@email.com	+55 11 99999-0003	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.923	2025-10-07 22:11:55.923	\N
3138a981-e63c-47ea-95b3-834a797af950	4a2d7176-3f9d-43da-9a7f-e97d08f54744	João Costa	joao.costa@email.com	+55 11 99999-0004	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.928	2025-10-07 22:11:55.928	\N
40fc20f3-8517-4d1f-be27-45c6eff86e7f	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Fernanda Lima	fernanda.lima@email.com	+55 11 99999-0005	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.932	2025-10-07 22:11:55.932	\N
52f97c9f-e174-48f3-906c-4c13add2f47e	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Pedro Alves	pedro.alves@email.com	+55 11 99999-0006	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.937	2025-10-07 22:11:55.937	\N
ed7d6ffb-8273-4316-8394-9ae757076482	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Juliana Rocha	juliana.rocha@email.com	+55 11 99999-0007	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.942	2025-10-07 22:11:55.942	\N
ceeaca49-e901-41d5-8c81-cc6cc09fd12e	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Rafael Souza	rafael.souza@email.com	+55 11 99999-0008	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.946	2025-10-07 22:11:55.946	\N
488444ca-9356-4c3e-819e-a8ad0031005c	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Camila Ferreira	camila.ferreira@email.com	+55 11 99999-0009	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.951	2025-10-07 22:11:55.951	\N
74744d73-90be-48e9-9884-aa103a5f3f91	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Lucas Martins	lucas.martins@email.com	+55 11 99999-0010	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.955	2025-10-07 22:11:55.955	\N
f0743ac5-a52e-4eb3-ba18-72cb00013562	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Patricia Gomes	patricia.gomes@email.com	+55 11 99999-0011	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.959	2025-10-07 22:11:55.959	\N
1eb96f17-661e-4e37-8bcb-13371c91cebf	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Diego Rodrigues	diego.rodrigues@email.com	+55 11 99999-0012	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.964	2025-10-07 22:11:55.964	\N
094dad4e-77bb-49c7-8f6b-8043bc5520a6	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Amanda Pereira	amanda.pereira@email.com	+55 11 99999-0013	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.968	2025-10-07 22:11:55.968	\N
6396a192-2f09-49f8-9739-368e143c323b	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Bruno Carvalho	bruno.carvalho@email.com	+55 11 99999-0014	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.973	2025-10-07 22:11:55.973	\N
8925fab5-304c-4ee8-a791-5590dc43f806	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Larissa Nunes	larissa.nunes@email.com	+55 11 99999-0015	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.979	2025-10-07 22:11:55.979	\N
1ac729a4-f041-4aab-ac1d-d0958372dddc	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Gabriel Silva	gabriel.silva@email.com	+55 11 99999-0016	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.983	2025-10-07 22:11:55.983	\N
7facff7a-e12e-4c1a-8661-0d171175f8f2	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Isabela Costa	isabela.costa@email.com	+55 11 99999-0017	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.989	2025-10-07 22:11:55.989	\N
e11fb842-8af1-44f8-83ef-8455f8c42f54	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Thiago Almeida	thiago.almeida@email.com	+55 11 99999-0018	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:55.994	2025-10-07 22:11:55.994	\N
b3336adf-5559-4602-b2e4-34b9c2294ae4	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Natália Barbosa	natalia.barbosa@email.com	+55 11 99999-0019	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56	2025-10-07 22:11:56	\N
92e3da2a-e84c-4093-b651-5f8b0d18ce40	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Marcos Vieira	marcos.vieira@email.com	+55 11 99999-0020	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.004	2025-10-07 22:11:56.004	\N
3b85212d-b1b6-4494-9e5e-6860e81ab2c1	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Sarah Johnson	sarah.johnson@expatriamente.com	+1 555-0101	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.721	2025-10-07 22:11:56.721	\N
eacf8450-1ad5-43fa-bb53-dada7ef2b95f	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Michael Chen	michael.chen@expatriamente.com	+1 555-0102	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.728	2025-10-07 22:11:56.728	\N
f88ee870-66b3-43d9-ae10-a25433a8724e	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Emily Rodriguez	emily.rodriguez@expatriamente.com	+1 555-0103	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.737	2025-10-07 22:11:56.737	\N
d0ee3f0f-2c4b-48b3-b92c-6a4cc26ffd63	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. James Wilson	james.wilson@expatriamente.com	+1 555-0104	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.744	2025-10-07 22:11:56.744	\N
c70a6af5-6796-498e-8db8-0f45d46e79e9	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Lisa Thompson	lisa.thompson@expatriamente.com	+1 555-0105	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.75	2025-10-07 22:11:56.75	\N
89d7e098-c14d-4652-926f-3debac96779d	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Robert Garcia	robert.garcia@expatriamente.com	+1 555-0106	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.755	2025-10-07 22:11:56.755	\N
78552b31-6316-4f78-8122-62bcc464a9df	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Jennifer Lee	jennifer.lee@expatriamente.com	+1 555-0107	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.759	2025-10-07 22:11:56.759	\N
c550cdde-f93f-4c98-8fbd-a1674db077ab	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. David Brown	david.brown@expatriamente.com	+1 555-0108	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.763	2025-10-07 22:11:56.763	\N
bb0844a4-5cc7-4f10-8121-2f5a5a8c73ff	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Maria Gonzalez	maria.gonzalez@expatriamente.com	+1 555-0109	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.768	2025-10-07 22:11:56.768	\N
c6ea1e4d-484e-4609-bc33-eea71b520037	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Kevin Taylor	kevin.taylor@expatriamente.com	+1 555-0110	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.772	2025-10-07 22:11:56.772	\N
0926ad32-cb18-4e0e-a66e-c4eb3a6f1a93	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Amanda White	amanda.white@expatriamente.com	+1 555-0111	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.78	2025-10-07 22:11:56.78	\N
40b11118-035d-4636-b4a7-5ae80221fad7	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Christopher Davis	christopher.davis@expatriamente.com	+1 555-0112	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.785	2025-10-07 22:11:56.785	\N
6758c63d-238d-446e-ad34-eafe4cc56eb8	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Rachel Miller	rachel.miller@expatriamente.com	+1 555-0113	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.79	2025-10-07 22:11:56.79	\N
31591bb9-de5b-44c7-b8ec-96e87b0ca003	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Daniel Anderson	daniel.anderson@expatriamente.com	+1 555-0114	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.795	2025-10-07 22:11:56.795	\N
22139cfd-dba9-4981-8d2d-6e962af4421e	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Jessica Martinez	jessica.martinez@expatriamente.com	+1 555-0115	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.801	2025-10-07 22:11:56.801	\N
11041e62-05b3-4c8c-b34b-09dc03383219	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Matthew Jackson	matthew.jackson@expatriamente.com	+1 555-0116	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.806	2025-10-07 22:11:56.806	\N
2496b194-40ff-4c3a-bc54-a226e060f70f	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Ashley Moore	ashley.moore@expatriamente.com	+1 555-0117	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.811	2025-10-07 22:11:56.811	\N
4c03ab93-4098-4b7a-84af-900ab2633191	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Andrew Clark	andrew.clark@expatriamente.com	+1 555-0118	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.818	2025-10-07 22:11:56.818	\N
6d87eccb-b1eb-4c4e-b255-991deb0629bf	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Samantha Lewis	samantha.lewis@expatriamente.com	+1 555-0119	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.824	2025-10-07 22:11:56.824	\N
eb9e4918-ee78-46f0-903c-d515fd166a49	2a2ad019-c94a-4f35-9dc8-dd877b3e8ec8	Dr. Ryan Walker	ryan.walker@expatriamente.com	+1 555-0120	\N	$2b$10$example.hash	CLIENT	ACTIVE	0	\N	\N	f	\N	\N	\N	\N	2025-10-07 22:11:56.829	2025-10-07 22:11:56.829	\N
037a7cdb-56a4-46ec-aad4-fb895524e60c	fff6a743-2689-4a31-b9db-9098bcccfd27	Guillermo	admin@ultradashboard.com	\N	\N	$2b$12$T5eym212pMRJ0GtejZ368Oe2TCISYEOoPnK0fVccq8iQKgZ8slUsq	SUPER_ADMIN	ACTIVE	0	\N	2025-10-09 23:41:32.275	f	\N	\N	\N	\N	2025-10-04 14:23:01.462	2025-10-09 23:41:32.281	\N
\.


--
-- Data for Name: wishlist_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wishlist_items (id, wishlist_id, product_id, "createdAt") FROM stdin;
\.


--
-- Data for Name: wishlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wishlists (id, customer_id, name, is_public, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: workspace_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workspace_members (id, workspace_id, user_id, role, joined_at, created_at, updated_at) FROM stdin;
87a78f3e-c50d-4ef1-b85b-2ad74bb5a368	2747c897-491f-4d44-b283-992f25b34d98	0b68319d-a3c2-4a6a-888d-27b732f7bca5	OWNER	2025-09-26 22:14:02.682	2025-09-26 22:14:02.682	2025-09-26 22:14:02.682
525d74a4-2100-47c6-b309-99e8ed45cfc2	2747c897-491f-4d44-b283-992f25b34d98	a4886bc8-8d6d-41bf-a759-ca82428e0b73	ADMIN	2025-09-26 22:19:36.364	2025-09-26 22:19:36.364	2025-09-26 22:19:36.364
\.


--
-- Data for Name: workspace_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workspace_notifications (id, client_id, workspace_id, user_id, type, title, message, data, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: workspace_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workspace_permissions (id, workspace_id, member_id, permission, granted_at, granted_by, created_at) FROM stdin;
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workspaces (id, client_id, name, description, is_public, created_by, created_at, updated_at) FROM stdin;
2747c897-491f-4d44-b283-992f25b34d98	4a2d7176-3f9d-43da-9a7f-e97d08f54744	Contas de Casa		f	0b68319d-a3c2-4a6a-888d-27b732f7bca5	2025-09-26 22:14:02.682	2025-09-26 22:14:02.682
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: analytics_reports analytics_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_reports
    ADD CONSTRAINT analytics_reports_pkey PRIMARY KEY (id);


--
-- Name: annotations annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: budget_categories budget_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_categories
    ADD CONSTRAINT budget_categories_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: doctor_appointments doctor_appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_appointments
    ADD CONSTRAINT doctor_appointments_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_order_items ecommerce_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_order_items
    ADD CONSTRAINT ecommerce_order_items_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_orders ecommerce_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_orders
    ADD CONSTRAINT ecommerce_orders_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: financial_goals financial_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_goals
    ADD CONSTRAINT financial_goals_pkey PRIMARY KEY (id);


--
-- Name: frontend_cache_metadata frontend_cache_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.frontend_cache_metadata
    ADD CONSTRAINT frontend_cache_metadata_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_leads property_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_leads
    ADD CONSTRAINT property_leads_pkey PRIMARY KEY (id);


--
-- Name: property_visits property_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_visits
    ADD CONSTRAINT property_visits_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: shared_data_audit shared_data_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shared_data_audit
    ADD CONSTRAINT shared_data_audit_pkey PRIMARY KEY (id);


--
-- Name: shipment_trackings shipment_trackings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment_trackings
    ADD CONSTRAINT shipment_trackings_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wishlist_items wishlist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_pkey PRIMARY KEY (id);


--
-- Name: wishlists wishlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_pkey PRIMARY KEY (id);


--
-- Name: workspace_members workspace_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_pkey PRIMARY KEY (id);


--
-- Name: workspace_notifications workspace_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_notifications
    ADD CONSTRAINT workspace_notifications_pkey PRIMARY KEY (id);


--
-- Name: workspace_permissions workspace_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_permissions
    ADD CONSTRAINT workspace_permissions_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: _EmployeeToService_AB_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "_EmployeeToService_AB_unique" ON public."_EmployeeToService" USING btree ("A", "B");


--
-- Name: _EmployeeToService_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_EmployeeToService_B_index" ON public."_EmployeeToService" USING btree ("B");


--
-- Name: analytics_events_clientId_eventType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_events_clientId_eventType_idx" ON public.analytics_events USING btree ("clientId", "eventType");


--
-- Name: analytics_events_clientId_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_events_clientId_timestamp_idx" ON public.analytics_events USING btree ("clientId", "timestamp");


--
-- Name: analytics_events_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_events_sessionId_idx" ON public.analytics_events USING btree ("sessionId");


--
-- Name: analytics_reports_clientId_reportType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_reports_clientId_reportType_idx" ON public.analytics_reports USING btree ("clientId", "reportType");


--
-- Name: analytics_reports_clientId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_reports_clientId_status_idx" ON public.analytics_reports USING btree ("clientId", status);


--
-- Name: annotations_appointment_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX annotations_appointment_id_idx ON public.annotations USING btree (appointment_id);


--
-- Name: annotations_client_id_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX annotations_client_id_user_id_created_at_idx ON public.annotations USING btree (client_id, user_id, created_at);


--
-- Name: appointments_client_id_startTime_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "appointments_client_id_startTime_idx" ON public.appointments USING btree (client_id, "startTime");


--
-- Name: appointments_client_id_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX appointments_client_id_status_idx ON public.appointments USING btree (client_id, status);


--
-- Name: appointments_employee_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX appointments_employee_id_idx ON public.appointments USING btree (employee_id);


--
-- Name: appointments_startTime_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "appointments_startTime_idx" ON public.appointments USING btree ("startTime");


--
-- Name: appointments_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX appointments_user_id_idx ON public.appointments USING btree (user_id);


--
-- Name: budget_categories_budget_id_category_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX budget_categories_budget_id_category_id_key ON public.budget_categories USING btree (budget_id, category_id);


--
-- Name: budget_categories_budget_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX budget_categories_budget_id_idx ON public.budget_categories USING btree (budget_id);


--
-- Name: budget_categories_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX budget_categories_category_id_idx ON public.budget_categories USING btree (category_id);


--
-- Name: budgets_client_id_period_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX budgets_client_id_period_idx ON public.budgets USING btree (client_id, period);


--
-- Name: budgets_client_id_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX budgets_client_id_user_id_idx ON public.budgets USING btree (client_id, user_id);


--
-- Name: budgets_client_id_workspace_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX budgets_client_id_workspace_id_idx ON public.budgets USING btree (client_id, workspace_id);


--
-- Name: budgets_workspace_id_period_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX budgets_workspace_id_period_idx ON public.budgets USING btree (workspace_id, period);


--
-- Name: clients_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX clients_email_key ON public.clients USING btree (email);


--
-- Name: clients_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX clients_slug_key ON public.clients USING btree (slug);


--
-- Name: clients_stripe_customer_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX clients_stripe_customer_id_key ON public.clients USING btree (stripe_customer_id);


--
-- Name: coupons_client_id_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX coupons_client_id_code_key ON public.coupons USING btree (client_id, code);


--
-- Name: customers_client_id_document_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX customers_client_id_document_key ON public.customers USING btree (client_id, document);


--
-- Name: customers_client_id_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX customers_client_id_email_key ON public.customers USING btree (client_id, email);


--
-- Name: doctors_client_id_crm_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX doctors_client_id_crm_key ON public.doctors USING btree (client_id, crm);


--
-- Name: ecommerce_orders_order_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ecommerce_orders_order_number_key ON public.ecommerce_orders USING btree (order_number);


--
-- Name: employees_client_id_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX employees_client_id_email_key ON public.employees USING btree (client_id, email);


--
-- Name: employees_client_id_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "employees_client_id_isActive_idx" ON public.employees USING btree (client_id, "isActive");


--
-- Name: employees_client_id_user_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX employees_client_id_user_id_key ON public.employees USING btree (client_id, user_id);


--
-- Name: employees_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employees_email_idx ON public.employees USING btree (email);


--
-- Name: financial_goals_client_id_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX financial_goals_client_id_status_idx ON public.financial_goals USING btree (client_id, status);


--
-- Name: financial_goals_client_id_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX financial_goals_client_id_user_id_idx ON public.financial_goals USING btree (client_id, user_id);


--
-- Name: financial_goals_client_id_workspace_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX financial_goals_client_id_workspace_id_idx ON public.financial_goals USING btree (client_id, workspace_id);


--
-- Name: financial_goals_workspace_id_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX financial_goals_workspace_id_status_idx ON public.financial_goals USING btree (workspace_id, status);


--
-- Name: frontend_cache_metadata_client_id_cache_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX frontend_cache_metadata_client_id_cache_key_idx ON public.frontend_cache_metadata USING btree (client_id, cache_key);


--
-- Name: frontend_cache_metadata_client_id_cache_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX frontend_cache_metadata_client_id_cache_key_key ON public.frontend_cache_metadata USING btree (client_id, cache_key);


--
-- Name: frontend_cache_metadata_client_id_last_updated_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX frontend_cache_metadata_client_id_last_updated_idx ON public.frontend_cache_metadata USING btree (client_id, last_updated);


--
-- Name: orders_client_id_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_client_id_createdAt_idx" ON public.orders USING btree (client_id, "createdAt");


--
-- Name: orders_client_id_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_client_id_paymentStatus_idx" ON public.orders USING btree (client_id, "paymentStatus");


--
-- Name: orders_client_id_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_client_id_status_idx ON public.orders USING btree (client_id, status);


--
-- Name: orders_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_createdAt_idx" ON public.orders USING btree ("createdAt");


--
-- Name: orders_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "orders_orderNumber_key" ON public.orders USING btree ("orderNumber");


--
-- Name: orders_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_user_id_idx ON public.orders USING btree (user_id);


--
-- Name: patients_client_id_document_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX patients_client_id_document_key ON public.patients USING btree (client_id, document);


--
-- Name: payments_payment_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX payments_payment_number_key ON public.payments USING btree (payment_number);


--
-- Name: product_variants_product_id_sku_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_variants_product_id_sku_key ON public.product_variants USING btree (product_id, sku);


--
-- Name: products_client_id_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX products_client_id_category_id_idx ON public.products USING btree (client_id, category_id);


--
-- Name: products_client_id_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_client_id_isActive_idx" ON public.products USING btree (client_id, "isActive");


--
-- Name: products_client_id_sku_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX products_client_id_sku_key ON public.products USING btree (client_id, sku);


--
-- Name: products_price_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX products_price_idx ON public.products USING btree (price);


--
-- Name: products_stock_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX products_stock_idx ON public.products USING btree (stock);


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: reviews_product_id_customer_id_order_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reviews_product_id_customer_id_order_id_key ON public.reviews USING btree (product_id, customer_id, order_id);


--
-- Name: schedules_client_id_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX schedules_client_id_category_idx ON public.schedules USING btree (client_id, category);


--
-- Name: schedules_client_id_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX schedules_client_id_date_idx ON public.schedules USING btree (client_id, date);


--
-- Name: schedules_client_id_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX schedules_client_id_priority_idx ON public.schedules USING btree (client_id, priority);


--
-- Name: schedules_client_id_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX schedules_client_id_status_idx ON public.schedules USING btree (client_id, status);


--
-- Name: schedules_client_id_user_id_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX schedules_client_id_user_id_date_idx ON public.schedules USING btree (client_id, user_id, date);


--
-- Name: schedules_client_id_user_id_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX schedules_client_id_user_id_date_key ON public.schedules USING btree (client_id, user_id, date);


--
-- Name: schedules_employee_id_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX schedules_employee_id_date_idx ON public.schedules USING btree (employee_id, date);


--
-- Name: services_client_id_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "services_client_id_isActive_idx" ON public.services USING btree (client_id, "isActive");


--
-- Name: services_price_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX services_price_idx ON public.services USING btree (price);


--
-- Name: shared_data_audit_client_id_action_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shared_data_audit_client_id_action_idx ON public.shared_data_audit USING btree (client_id, action);


--
-- Name: shared_data_audit_client_id_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shared_data_audit_client_id_user_id_idx ON public.shared_data_audit USING btree (client_id, user_id);


--
-- Name: shared_data_audit_client_id_workspace_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shared_data_audit_client_id_workspace_id_idx ON public.shared_data_audit USING btree (client_id, workspace_id);


--
-- Name: shared_data_audit_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shared_data_audit_created_at_idx ON public.shared_data_audit USING btree (created_at);


--
-- Name: shared_data_audit_entity_entity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shared_data_audit_entity_entity_id_idx ON public.shared_data_audit USING btree (entity, entity_id);


--
-- Name: shared_data_audit_workspace_id_action_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shared_data_audit_workspace_id_action_idx ON public.shared_data_audit USING btree (workspace_id, action);


--
-- Name: shipments_tracking_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX shipments_tracking_code_key ON public.shipments USING btree (tracking_code);


--
-- Name: suppliers_client_id_document_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX suppliers_client_id_document_key ON public.suppliers USING btree (client_id, document);


--
-- Name: transactions_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_category_id_idx ON public.transactions USING btree (category_id);


--
-- Name: transactions_client_id_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_client_id_date_idx ON public.transactions USING btree (client_id, date);


--
-- Name: transactions_client_id_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_client_id_status_idx ON public.transactions USING btree (client_id, status);


--
-- Name: transactions_client_id_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_client_id_type_idx ON public.transactions USING btree (client_id, type);


--
-- Name: transactions_client_id_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_client_id_user_id_idx ON public.transactions USING btree (client_id, user_id);


--
-- Name: transactions_client_id_workspace_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_client_id_workspace_id_idx ON public.transactions USING btree (client_id, workspace_id);


--
-- Name: transactions_workspace_id_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX transactions_workspace_id_date_idx ON public.transactions USING btree (workspace_id, date);


--
-- Name: users_client_id_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_client_id_email_key ON public.users USING btree (client_id, email);


--
-- Name: users_client_id_employee_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_client_id_employee_id_key ON public.users USING btree (client_id, employee_id);


--
-- Name: users_client_id_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_client_id_role_idx ON public.users USING btree (client_id, role);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_employee_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_employee_id_idx ON public.users USING btree (employee_id);


--
-- Name: users_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_status_idx ON public.users USING btree (status);


--
-- Name: wishlist_items_wishlist_id_product_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX wishlist_items_wishlist_id_product_id_key ON public.wishlist_items USING btree (wishlist_id, product_id);


--
-- Name: workspace_members_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_members_user_id_idx ON public.workspace_members USING btree (user_id);


--
-- Name: workspace_members_workspace_id_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_members_workspace_id_role_idx ON public.workspace_members USING btree (workspace_id, role);


--
-- Name: workspace_members_workspace_id_user_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX workspace_members_workspace_id_user_id_key ON public.workspace_members USING btree (workspace_id, user_id);


--
-- Name: workspace_notifications_client_id_user_id_is_read_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_notifications_client_id_user_id_is_read_idx ON public.workspace_notifications USING btree (client_id, user_id, is_read);


--
-- Name: workspace_notifications_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_notifications_created_at_idx ON public.workspace_notifications USING btree (created_at);


--
-- Name: workspace_notifications_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_notifications_type_idx ON public.workspace_notifications USING btree (type);


--
-- Name: workspace_notifications_workspace_id_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_notifications_workspace_id_user_id_idx ON public.workspace_notifications USING btree (workspace_id, user_id);


--
-- Name: workspace_permissions_member_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_permissions_member_id_idx ON public.workspace_permissions USING btree (member_id);


--
-- Name: workspace_permissions_workspace_id_member_id_permission_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX workspace_permissions_workspace_id_member_id_permission_key ON public.workspace_permissions USING btree (workspace_id, member_id, permission);


--
-- Name: workspace_permissions_workspace_id_permission_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspace_permissions_workspace_id_permission_idx ON public.workspace_permissions USING btree (workspace_id, permission);


--
-- Name: workspaces_client_id_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspaces_client_id_created_by_idx ON public.workspaces USING btree (client_id, created_by);


--
-- Name: workspaces_client_id_is_public_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspaces_client_id_is_public_idx ON public.workspaces USING btree (client_id, is_public);


--
-- Name: workspaces_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX workspaces_name_idx ON public.workspaces USING btree (name);


--
-- Name: _EmployeeToService _EmployeeToService_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeToService"
    ADD CONSTRAINT "_EmployeeToService_A_fkey" FOREIGN KEY ("A") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _EmployeeToService _EmployeeToService_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeToService"
    ADD CONSTRAINT "_EmployeeToService_B_fkey" FOREIGN KEY ("B") REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: addresses addresses_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_events analytics_events_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT "analytics_events_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_events analytics_events_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT "analytics_events_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: analytics_reports analytics_reports_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_reports
    ADD CONSTRAINT "analytics_reports_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotations annotations_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: annotations annotations_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotations annotations_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: annotations annotations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budget_categories budget_categories_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_categories
    ADD CONSTRAINT budget_categories_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.budgets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budget_categories budget_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_categories
    ADD CONSTRAINT budget_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budgets budgets_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budgets budgets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: budgets budgets_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_items cart_items_cart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_cart_id_fkey FOREIGN KEY (cart_id) REFERENCES public.carts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_items cart_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cart_items cart_items_product_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_product_variant_id_fkey FOREIGN KEY (product_variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: carts carts_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: carts carts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coupons coupons_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customers customers_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctor_appointments doctor_appointments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_appointments
    ADD CONSTRAINT doctor_appointments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctor_appointments doctor_appointments_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_appointments
    ADD CONSTRAINT doctor_appointments_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctor_appointments doctor_appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_appointments
    ADD CONSTRAINT doctor_appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctors doctors_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctors doctors_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ecommerce_order_items ecommerce_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_order_items
    ADD CONSTRAINT ecommerce_order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.ecommerce_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ecommerce_order_items ecommerce_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_order_items
    ADD CONSTRAINT ecommerce_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ecommerce_order_items ecommerce_order_items_product_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_order_items
    ADD CONSTRAINT ecommerce_order_items_product_variant_id_fkey FOREIGN KEY (product_variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ecommerce_orders ecommerce_orders_billing_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_orders
    ADD CONSTRAINT ecommerce_orders_billing_address_id_fkey FOREIGN KEY (billing_address_id) REFERENCES public.addresses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ecommerce_orders ecommerce_orders_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_orders
    ADD CONSTRAINT ecommerce_orders_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ecommerce_orders ecommerce_orders_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_orders
    ADD CONSTRAINT ecommerce_orders_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ecommerce_orders ecommerce_orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_orders
    ADD CONSTRAINT ecommerce_orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ecommerce_orders ecommerce_orders_shipping_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ecommerce_orders
    ADD CONSTRAINT ecommerce_orders_shipping_address_id_fkey FOREIGN KEY (shipping_address_id) REFERENCES public.addresses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financial_goals financial_goals_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_goals
    ADD CONSTRAINT financial_goals_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financial_goals financial_goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_goals
    ADD CONSTRAINT financial_goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financial_goals financial_goals_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_goals
    ADD CONSTRAINT financial_goals_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: frontend_cache_metadata frontend_cache_metadata_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.frontend_cache_metadata
    ADD CONSTRAINT frontend_cache_metadata_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: patients patients_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.ecommerce_orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: products products_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: properties properties_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_leads property_leads_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_leads
    ADD CONSTRAINT property_leads_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_leads property_leads_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_leads
    ADD CONSTRAINT property_leads_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_visits property_visits_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_visits
    ADD CONSTRAINT property_visits_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_visits property_visits_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_visits
    ADD CONSTRAINT property_visits_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.ecommerce_orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reviews reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: schedules schedules_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: schedules schedules_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: schedules schedules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: services services_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: services services_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shared_data_audit shared_data_audit_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shared_data_audit
    ADD CONSTRAINT shared_data_audit_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shared_data_audit shared_data_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shared_data_audit
    ADD CONSTRAINT shared_data_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shared_data_audit shared_data_audit_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shared_data_audit
    ADD CONSTRAINT shared_data_audit_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shipment_trackings shipment_trackings_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment_trackings
    ADD CONSTRAINT shipment_trackings_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipments shipments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.ecommerce_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: suppliers suppliers_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: wishlist_items wishlist_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: wishlist_items wishlist_items_wishlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_wishlist_id_fkey FOREIGN KEY (wishlist_id) REFERENCES public.wishlists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: wishlists wishlists_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_members workspace_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_members workspace_members_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_members
    ADD CONSTRAINT workspace_members_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_notifications workspace_notifications_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_notifications
    ADD CONSTRAINT workspace_notifications_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_notifications workspace_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_notifications
    ADD CONSTRAINT workspace_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_notifications workspace_notifications_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_notifications
    ADD CONSTRAINT workspace_notifications_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workspace_permissions workspace_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_permissions
    ADD CONSTRAINT workspace_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_permissions workspace_permissions_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_permissions
    ADD CONSTRAINT workspace_permissions_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.workspace_members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_permissions workspace_permissions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspace_permissions
    ADD CONSTRAINT workspace_permissions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspaces workspaces_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspaces workspaces_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict UzprzrWjLsDMn9IAO1lVB5jPlua2AwWo73F5QH3v1sSkNlBmQR6hf6NTvwFxBht

